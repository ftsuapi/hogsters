
# MelvorCord Idle (Discord Idle RPG)

A lightweight, Melvor Idle–inspired Discord bot written in Python using `discord.py` 2.x.
It uses components (buttons + dropdowns), embeds, and a global tick loop to process
idle jobs like Woodcutting and Fishing.

## Quick Start

1) **Install deps** (Python 3.10+ recommended):
```bash
pip install -r requirements.txt
```

2) **Create `.env`** from example and paste your token:
```
cp .env.example .env
# open .env and set DISCORD_TOKEN=...
```

3) **Run the bot**:
```bash
python main.py
```

Invite it to a server, then use `/start` to register. Use `/menu` to open the main menu.

## Features (starter pack)
- JSON persistence per user (in `./data/users/<id>.json`)
- Skills: **Woodcutting**, **Fishing**
- Start/Stop jobs with buttons
- Ticking loop (every 5 seconds) grants XP and items
- Leveling curve with level caps and experience table
- Inventory & profile displays
- Simple Shop stub you can expand
- Leaderboard (XP total)

## Project Layout
```
melvorcord/
 ├─ main.py
 ├─ game/
 │   ├─ __init__.py
 │   ├─ data.py         # persistence
 │   ├─ models.py       # data models & defaults
 │   ├─ leveling.py     # xp <-> level helpers
 │   ├─ jobs.py         # job engine / tick loop
 │   ├─ views.py        # discord UI (buttons/dropdowns)
 │   └─ embeds.py       # embed builders
 ├─ requirements.txt
 ├─ .env.example
 └─ README.md
```

## Notes
- This is a foundation. Add more skills, items, drop tables, quests, pets, etc.
- To make views persistent across restarts, you can register them with `bot.add_view()`
  and give custom_id for each item. Here we use ephemeral views created per menu open.
- For production, consider SQLite instead of JSON, and break skills/items into config files.
