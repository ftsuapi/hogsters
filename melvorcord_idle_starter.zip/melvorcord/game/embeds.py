
from __future__ import annotations
import discord
from typing import Dict
from .models import Player, DEFAULT_ITEMS
from .leveling import level_for_xp, xp_to_next

def main_menu_embed(user: discord.User | discord.Member, p: Player) -> discord.Embed:
    e = discord.Embed(title="🏝️ MelvorCord Idle — Main Menu", color=discord.Color.blurple())
    e.set_author(name=str(user), icon_url=user.display_avatar.url if hasattr(user, "display_avatar") else discord.Embed.Empty)
    e.add_field(name="Coins", value=f"{p.coins:,}", inline=True)
    e.add_field(name="Total XP", value=f"{p.total_xp:,}", inline=True)
    if p.active_job:
        e.add_field(name="Current Job", value=f"**{p.active_job['skill']}** (ticking)", inline=False)
    else:
        e.add_field(name="Current Job", value="*None*", inline=False)
    return e

def profile_embed(user, p: Player) -> discord.Embed:
    e = discord.Embed(title="🧑 Profile", color=discord.Color.green())
    e.set_thumbnail(url=user.display_avatar.url if hasattr(user, "display_avatar") else discord.Embed.Empty)
    lines = []
    for name, st in p.skills.items():
        lines.append(f"**{name}** — Lvl {st.level} ({st.xp:,} XP, {xp_to_next(st.xp):,} to next)")
    e.add_field(name="Skills", value="\n".join(lines) or "None", inline=False)
    e.add_field(name="Coins", value=f"{p.coins:,}", inline=True)
    e.add_field(name="Total XP", value=f"{p.total_xp:,}", inline=True)
    return e

def inventory_embed(p: Player) -> discord.Embed:
    e = discord.Embed(title="🎒 Inventory", color=discord.Color.gold())
    if not p.inventory:
        e.description = "*Empty.*"
        return e
    lines = []
    for item_id, qty in p.inventory.items():
        item = DEFAULT_ITEMS.get(item_id, {"name": item_id})
        lines.append(f"**{item['name']}** × {qty}")
    e.description = "\n".join(lines)
    return e

def job_update_embed(skill: str, xp: int, items: Dict[str, int]) -> discord.Embed:
    e = discord.Embed(title=f"⏳ {skill} — Tick Results", color=discord.Color.blurple())
    lines = [f"+{xp} XP"]
    for item_id, q in items.items():
        lines.append(f"• {item_id} × {q}")
    e.description = "\n".join(lines) if lines else "No gains this tick."
    return e

def leaderboard_embed(rows) -> discord.Embed:
    e = discord.Embed(title="🏆 Global Leaderboard (Total XP)", color=discord.Color.purple())
    if not rows:
        e.description = "*No players yet.*"
        return e
    lines = []
    for i, (user_id, total_xp) in enumerate(rows, start=1):
        lines.append(f"**{i}.** <@{user_id}> — {total_xp:,} XP")
    e.description = "\n".join(lines)
    return e
