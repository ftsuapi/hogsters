
from __future__ import annotations
import time, random
from typing import Dict, Tuple
from .models import Player, DEFAULT_ITEMS
from .leveling import level_for_xp

# Job engine: called on every tick for active players.
# Returns (xp_gain, items_gained dict)

TICK_SECONDS = 5

SKILL_CONFIG = {
    "Woodcutting": {
        "xp_per_tick": 8,
        "drops": [
            ("log", 0.80, (1, 2)),
            ("oak_log", 0.20, (1, 1)),
        ],
    },
    "Fishing": {
        "xp_per_tick": 8,
        "drops": [
            ("fish_raw", 0.80, (1, 2)),
            ("salmon_raw", 0.20, (1, 1)),
        ],
    },
}

def roll_drops(drops) -> Dict[str, int]:
    got: Dict[str, int] = {}
    for item_id, chance, (lo, hi) in drops:
        if random.random() <= chance:
            qty = random.randint(lo, hi)
            got[item_id] = got.get(item_id, 0) + qty
    return got

def process_tick(player: Player) -> Tuple[int, Dict[str, int]]:
    if not player.active_job:
        return 0, {}
    skill = player.active_job.get("skill")
    cfg = SKILL_CONFIG.get(skill)
    if not cfg:
        return 0, {}
    xp = cfg["xp_per_tick"]
    items = roll_drops(cfg["drops"])
    # apply
    ps = player.skills[skill]
    ps.xp += xp
    player.total_xp += xp
    for item_id, q in items.items():
        player.inventory[item_id] = player.inventory.get(item_id, 0) + q
    # update level (lazy)
    ps.level = level_for_xp(ps.xp)
    return xp, items
