
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Dict, Any, Optional

SKILLS = ["Woodcutting", "Fishing"]

DEFAULT_ITEMS = {
    "log": {"name": "Log", "value": 2},
    "oak_log": {"name": "Oak Log", "value": 5},
    "fish_raw": {"name": "Raw Fish", "value": 3},
    "salmon_raw": {"name": "Raw Salmon", "value": 7},
}

@dataclass
class SkillState:
    xp: int = 0
    level: int = 1

@dataclass
class Player:
    user_id: int
    coins: int = 0
    total_xp: int = 0
    active_job: Optional[Dict[str, Any]] = None  # {"skill":str, "started":ts, "power":int}
    skills: Dict[str, SkillState] = field(default_factory=lambda: {k: SkillState() for k in SKILLS})
    inventory: Dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        # dataclasses nested conversion is fine.
        return d

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "Player":
        p = Player(user_id=d["user_id"])
        p.coins = d.get("coins", 0)
        p.total_xp = d.get("total_xp", 0)
        p.active_job = d.get("active_job", None)
        # skills
        p.skills = {k: SkillState(**v) for k, v in d.get("skills", {}).items()}
        # ensure missing skills exist
        for k in SKILLS:
            if k not in p.skills:
                p.skills[k] = SkillState()
        p.inventory = d.get("inventory", {})
        return p
