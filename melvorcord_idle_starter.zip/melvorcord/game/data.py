
from __future__ import annotations
import json, os
from typing import Optional
from .models import Player

DATA_DIR = os.path.join(os.getcwd(), "data", "users")
os.makedirs(DATA_DIR, exist_ok=True)

def path_for(user_id: int) -> str:
    return os.path.join(DATA_DIR, f"{user_id}.json")

def load_player(user_id: int) -> Player:
    p = path_for(user_id)
    if not os.path.exists(p):
        return Player(user_id=user_id)
    with open(p, "r", encoding="utf-8") as f:
        data = json.load(f)
    return Player.from_dict(data)

def save_player(player: Player) -> None:
    p = path_for(player.user_id)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(player.to_dict(), f, indent=2)
