
from __future__ import annotations

# Simple XP curve utilities.

LEVEL_CAP = 99

# Using a RuneScape-like curve: XP for level n ~ sum( floor(n + 300*2^(n/7)) )
# We'll precompute a small table for 1..99.
def build_xp_table(cap: int = LEVEL_CAP) -> list[int]:
    xp_table = [0] * (cap + 2)  # index is level; store min xp required for that level
    points = 0
    for lvl in range(1, cap + 1):
        points += int(lvl + 300 * (2 ** (lvl / 7.0)))
        xp_table[lvl] = points // 4
    xp_table[cap + 1 - 1] = xp_table[cap]  # keep length consistent
    return xp_table

XP_TABLE = build_xp_table()

def level_for_xp(xp: int) -> int:
    lvl = 1
    for i in range(1, LEVEL_CAP + 1):
        if xp < XP_TABLE[i]:
            lvl = i - 1
            break
        lvl = i
    return lvl

def xp_to_next(xp: int) -> int:
    lvl = level_for_xp(xp)
    if lvl >= LEVEL_CAP:
        return 0
    return max(0, XP_TABLE[lvl + 1] - xp)
