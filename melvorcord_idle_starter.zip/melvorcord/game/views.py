
from __future__ import annotations
import discord, asyncio, time
from typing import Optional, Dict
from .data import load_player, save_player
from .embeds import main_menu_embed, profile_embed, inventory_embed, leaderboard_embed
from .jobs import process_tick, TICK_SECONDS
from .models import SKILLS

# Active sessions: map channel_id->message_id for updating? We'll keep it simple:
ACTIVE_USERS: Dict[int, float] = {}  # user_id -> last_opened_ts

class MainMenu(discord.ui.View):
    def __init__(self, user_id: int):
        super().__init__(timeout=180)
        self.user_id = user_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("This menu isn't for you. Use `/menu` to open your own.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Profile", style=discord.ButtonStyle.green, emoji="🧑")
    async def profile_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        p = load_player(self.user_id)
        await interaction.response.edit_message(embed=profile_embed(interaction.user, p), view=self)

    @discord.ui.button(label="Skills", style=discord.ButtonStyle.blurple, emoji="🛠️")
    async def skills_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        view = SkillsView(self.user_id, parent=self)
        await interaction.response.edit_message(content=None, embed=view.render(interaction.user), view=view)

    @discord.ui.button(label="Inventory", style=discord.ButtonStyle.gray, emoji="🎒")
    async def inv_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        p = load_player(self.user_id)
        await interaction.response.edit_message(embed=inventory_embed(p), view=self)

    @discord.ui.button(label="Leaderboard", style=discord.ButtonStyle.purple, emoji="🏆")
    async def lb_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        # naive global leaderboard by scanning data files
        import os, json
        data_dir = os.path.join(os.getcwd(), "data", "users")
        rows = []
        if os.path.isdir(data_dir):
            for f in os.listdir(data_dir):
                if not f.endswith(".json"): continue
                with open(os.path.join(data_dir, f), "r", encoding="utf-8") as fh:
                    d = json.load(fh)
                rows.append((int(d["user_id"]), int(d.get("total_xp", 0))))
        rows.sort(key=lambda x: x[1], reverse=True)
        rows = rows[:10]
        await interaction.response.edit_message(embed=leaderboard_embed(rows), view=self)

    @discord.ui.button(label="Shop (stub)", style=discord.ButtonStyle.gray, emoji="🛒")
    async def shop_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        e = discord.Embed(title="🛒 Shop", description="Coming soon! Sell items, buy gear, unlock upgrades.", color=discord.Color.gold())
        await interaction.response.edit_message(embed=e, view=self)

    @discord.ui.button(label="Main Menu", style=discord.ButtonStyle.red, emoji="🏠")
    async def main_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        p = load_player(self.user_id)
        await interaction.response.edit_message(embed=main_menu_embed(interaction.user, p), view=self)

    def render(self, user) -> discord.Embed:
        p = load_player(self.user_id)
        return main_menu_embed(user, p)

class SkillsView(discord.ui.View):
    def __init__(self, user_id: int, parent: MainMenu):
        super().__init__(timeout=180)
        self.user_id = user_id
        self.parent = parent
        self.add_item(SkillDropdown(user_id))

    @discord.ui.button(label="Start", style=discord.ButtonStyle.green, emoji="▶️")
    async def start_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        p = load_player(self.user_id)
        dd: SkillDropdown = self.children[0]  # type: ignore
        skill = dd.value or "Woodcutting"
        p.active_job = {"skill": skill, "started": time.time(), "power": 1}
        save_player(p)
        await interaction.response.edit_message(content=f"Started **{skill}**!", embed=self.render(interaction.user), view=self)

    @discord.ui.button(label="Stop", style=discord.ButtonStyle.red, emoji="⏹️")
    async def stop_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        p = load_player(self.user_id)
        if p.active_job:
            skill = p.active_job.get("skill", "Unknown")
            p.active_job = None
            save_player(p)
            await interaction.response.edit_message(content=f"Stopped **{skill}**.", embed=self.render(interaction.user), view=self)
        else:
            await interaction.response.send_message("You're not doing any job.", ephemeral=True)

    @discord.ui.button(label="Main Menu", style=discord.ButtonStyle.gray, emoji="🏠")
    async def main_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(embed=self.parent.render(interaction.user), view=self.parent)

    def render(self, user) -> discord.Embed:
        import discord
        p = load_player(self.user_id)
        e = discord.Embed(title="🛠️ Skills", color=discord.Color.blurple())
        e.description = "Select a skill, then press **Start** to begin idling. Use **Stop** to pause."
        lines = []
        for s, st in p.skills.items():
            lines.append(f"**{s}** — Lvl {st.level} ({st.xp:,} XP)")
        e.add_field(name="Your Skills", value="\n".join(lines) or "None", inline=False)
        if p.active_job:
            e.add_field(name="Active Job", value=f"{p.active_job['skill']}", inline=False)
        return e

class SkillDropdown(discord.ui.Select):
    def __init__(self, user_id: int):
        opts = [discord.SelectOption(label=s, value=s) for s in SKILLS]
        super().__init__(placeholder="Choose a skill…", min_values=1, max_values=1, options=opts)
        self.user_id = user_id
        self.value = None

    async def callback(self, interaction: discord.Interaction):
        self.value = self.values[0]
        await interaction.response.send_message(f"Selected **{self.value}**.", ephemeral=True)

# Background ticker. We'll run one loop that pings any ACTIVE_USERS recently using menus.
async def tick_loop(bot: discord.Client):
    await bot.wait_until_ready()
    channel_cache: Dict[int, int] = {}
    while not bot.is_closed():
        now = time.time()
        # process every known user who opened menu in last 30 minutes
        to_process = [uid for uid, ts in list(ACTIVE_USERS.items()) if now - ts <= 30 * 60]
        messages = []
        for uid in to_process:
            p = load_player(uid)
            xp, items = process_tick(p)
            if xp or items:
                save_player(p)
                messages.append((uid, xp, items, p.active_job["skill"] if p.active_job else "Job"))
        # we won't spam channels; just DM users with tick updates
        for uid, xp, items, skill in messages:
            try:
                user = await bot.fetch_user(uid)
                await user.send(f"+{xp} XP in **{skill}**; gains: {', '.join([f'{k}×{v}' for k,v in items.items()]) or 'none'}")
            except Exception:
                pass
        await asyncio.sleep(TICK_SECONDS)
