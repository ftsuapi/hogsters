
import os, asyncio, discord
from discord.ext import commands
from dotenv import load_dotenv

from game.data import load_player, save_player
from game.views import MainMenu, ACTIVE_USERS, tick_loop

intents = discord.Intents.default()
intents.members = True
intents.message_content = False

load_dotenv()

bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready():
    print(f"Logged in as {bot.user} (ID: {bot.user.id})")
    # start ticker
    bot.loop.create_task(tick_loop(bot))

@bot.tree.command(description="Register your account (first time only).")
async def start(interaction: discord.Interaction):
    p = load_player(interaction.user.id)
    save_player(p)
    await interaction.response.send_message("Account created (or already exists). Use `/menu` to open the game!", ephemeral=True)

@bot.tree.command(description="Open your main menu.")
async def menu(interaction: discord.Interaction):
    p = load_player(interaction.user.id)
    view = MainMenu(interaction.user.id)
    ACTIVE_USERS[interaction.user.id] = __import__("time").time()
    await interaction.response.send_message(embed=view.render(interaction.user), view=view, ephemeral=True)

# Sync tree on startup (once)
@bot.command(name="sync", help="Owner-only: sync slash commands.")
@commands.is_owner()
async def sync_cmd(ctx: commands.Context):
    await bot.tree.sync()
    await ctx.reply("Slash commands synced.")

def main():
    token = os.getenv("DISCORD_TOKEN")
    if not token:
        raise SystemExit("Missing DISCORD_TOKEN in .env")
    bot.run(token)

if __name__ == "__main__":
    main()
