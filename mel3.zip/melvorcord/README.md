# Melvorcord — Melvor Idle–style Discord Bot (Python)

A compact idle game for Discord using embeds, buttons, and a dropdown. Builds passive progress between interactions.

## Features
- **Skills**: Woodcutting, Mining, Fishing; **Processing**: Cooking (uses Fish) & Firemaking (uses Logs)
- **Idle/offline progress** using timestamps — progress accrues while you're away
- **Inventory and Gold**, **Sell All** button, and **Upgrades** (+10% speed / level)
- **Persistent UI** (buttons/select keep working after restarts)
- **Leaderboards** (total levels) and profile card

## Setup

1. Create a Discord application and bot at https://discord.com/developers/applications
2. Give the bot the **bot** scope and **applications.commands** scope.
3. Invite it to your server with the proper permissions: `Send Messages`, `Embed Links`, `Use Slash Commands`.
4. In your project folder:
   ```bash
   python -m venv .venv && . .venv/bin/activate  # Windows: .venv\Scripts\activate
   pip install -r requirements.txt
   cp .env.example .env
   # Edit .env and paste your token
   ```
5. Run it:
   ```bash
   python main.py
   ```

> Tip: If you set `GUILD_ID` in `.env`, slash commands sync instantly to that one guild during development. Remove it (or unset) for global sync later.

## Playing

- Use `/play` in a channel to spawn your **Main Menu**. The menu includes:
  - **Skill dropdown** to start a skill
  - **Stop** to stop training
  - **Profile** to see XP bars, levels, gold, tool level
  - **Inventory** to see items
  - **Sell All** to convert gathered items into gold
  - **Upgrade Tool** to spend gold for faster training in the active skill (+10% / upgrade)
  - **Leaderboard** for global total levels

The view is **persistent**, so it will keep working after a bot restart.

## Save Data

- Player progress is stored in `data.json` (configurable with `DATA_PATH`).
- File writes are atomic and guarded by an async lock.

## Notes & Tweaks

- Rates are intentionally modest (3/min for Woodcutting/Fishing at base). Tweak `SKILLS` in `main.py` to rebalance.
- Processing skills consume inputs. If you run Cooking without Fish, nothing happens until you gather more.
- The XP curve uses a RuneScape-style function; change `xp_for_level()` to re-shape the grind.
- You can create a dedicated `#idle-game` channel to avoid clutter.

## Troubleshooting

- **Slash commands not showing**: If you set `GUILD_ID`, make sure it's the correct server ID. Otherwise, global sync can take up to an hour to appear; use a guild ID during dev.
- **Missing token**: Ensure `DISCORD_TOKEN` is set (use `.env`).

— Generated on 2025-08-21
