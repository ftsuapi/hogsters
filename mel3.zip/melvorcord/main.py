
# Melvorcord: A Melvor Idle–style Discord bot (single-file)
# Features:
# - Slash command /play to spawn a persistent main menu with embeds, buttons, and a dropdown
# - Skills: Woodcutting, Mining, Fishing (gathering); optional Processing: Cooking (consumes Fish), Firemaking (consumes Logs)
# - Idle/offline progress based on timestamps (no tick loss between sessions)
# - Inventory, gold, upgrades (+10% speed per upgrade level), sell-all
# - Leaderboard (total level), profile
# - JSON persistence with async locks
# - Persistent components (buttons/select) survive restarts via custom_id
#
# Quick start:
# 1) pip install -r requirements.txt
# 2) Set DISCORD_TOKEN in your environment (or copy .env.example -> .env and fill it)
# 3) python main.py
# 4) Use /play in a server channel. (Optionally set GUILD_ID for faster slash sync in one guild)
#
# Notes:
# - Ephemeral views cannot be persistent, so the menu posts in-channel.
# - You can create a dedicated #idle-game channel for cleaner UX.

import os
import json
import asyncio
import logging
import math
import time
from datetime import datetime, timezone
from typing import Dict, Any, Optional, List, Tuple

import discord
from discord import app_commands
from discord.ext import commands, tasks

# ---------- Config & Logging ----------
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
log = logging.getLogger("melvorcord")

TOKEN = os.getenv("DISCORD_TOKEN") or os.getenv("TOKEN")
GUILD_ID_ENV = os.getenv("GUILD_ID")
GUILD_ID = int(GUILD_ID_ENV) if GUILD_ID_ENV and GUILD_ID_ENV.isdigit() else None

DATA_PATH = os.getenv("DATA_PATH", "data.json")

# ---------- Game Data ----------
# Items per second = base_rate * (1 + 0.05*(level-1)) * (1 + 0.1*(upgrade_level-1))
SKILLS: Dict[str, Dict[str, Any]] = {
    "Woodcutting": {"base_rate": 0.05, "xp_per_item": 10, "resource": "Logs", "value": 1, "type": "gather"},
    "Mining":      {"base_rate": 0.04, "xp_per_item": 12, "resource": "Ore",  "value": 2, "type": "gather"},
    "Fishing":     {"base_rate": 0.05, "xp_per_item": 9,  "resource": "Fish", "value": 2, "type": "gather"},
    "Cooking":     {"base_rate": 0.06, "xp_per_item": 8,  "resource": "Cooked Fish", "value": 3, "type": "process", "input": {"Fish": 1}},
    "Firemaking":  {"base_rate": 0.08, "xp_per_item": 7,  "resource": "Charcoal",    "value": 1, "type": "process", "input": {"Logs": 1}},
}

ALL_ITEMS = sorted({data["resource"] for data in SKILLS.values()}.union({"Logs", "Ore", "Fish"}))

# ---------- Utilities ----------
def now_ts() -> float:
    return datetime.now(timezone.utc).timestamp()

def clamp(n, a, b):
    return max(a, min(b, n))

def xp_for_level(level: int) -> int:
    """Classic RS-style-ish curve; total XP to *reach* level N."""
    points = 0
    for i in range(1, level):
        points += math.floor(i + 300 * (2 ** (i / 7.0)))
    return math.floor(points / 4)

def level_from_xp(xp: float) -> int:
    level = 1
    while xp_for_level(level + 1) <= xp and level < 120:
        level += 1
    return level

def next_level_xp(level: int) -> int:
    return xp_for_level(level + 1)

def progress_bar(current: float, total: float, length: int = 16) -> str:
    if total <= 0:
        return "—" * length
    ratio = clamp(current / total, 0.0, 1.0)
    filled = int(length * ratio)
    return "▰" * filled + "▱" * (length - filled)

# ---------- Persistence ----------
class DataManager:
    def __init__(self, path: str):
        self.path = path
        self.lock = asyncio.Lock()
        self.data: Dict[str, Any] = {"users": {}}
        self._loaded = False

    async def load(self):
        async with self.lock:
            if self._loaded:
                return
            if os.path.exists(self.path):
                try:
                    with open(self.path, "r", encoding="utf-8") as f:
                        self.data = json.load(f)
                except Exception as e:
                    log.exception("Failed to load data.json, starting fresh: %s", e)
                    self.data = {"users": {}}
            self._loaded = True

    async def save(self):
        async with self.lock:
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.data, f, indent=2)
            os.replace(tmp, self.path)

    def _default_user(self, user_id: int) -> Dict[str, Any]:
        return {
            "gold": 0,
            "skills": {name: {"xp": 0.0} for name in SKILLS.keys()},
            "inventory": {item: 0 for item in ALL_ITEMS},
            "upgrades": {name: 1 for name in SKILLS.keys()},  # starts at 1
            "action": None,  # {"skill": str, "last_tick": ts}
            "created": now_ts(),
            "last_seen": now_ts(),
        }

    async def get_user(self, user_id: int) -> Dict[str, Any]:
        await self.load()
        uid = str(user_id)
        if uid not in self.data["users"]:
            self.data["users"][uid] = self._default_user(user_id)
        self.data["users"][uid]["last_seen"] = now_ts()
        return self.data["users"][uid]

    async def get_all_users(self) -> List[Tuple[int, Dict[str, Any]]]:
        await self.load()
        return [(int(uid), udata) for uid, udata in self.data.get("users", {}).items()]

# ---------- Engine ----------
class Engine:
    def __init__(self, dm: DataManager):
        self.dm = dm

    def _rate_per_sec(self, skill_name: str, level: int, upgrade_level: int) -> float:
        base = SKILLS[skill_name]["base_rate"]
        lvl_mult = 1.0 + 0.05 * max(0, level - 1)       # +5% per level
        upg_mult = 1.0 + 0.10 * max(0, upgrade_level - 1)  # +10% per upgrade
        return base * lvl_mult * upg_mult

    async def start_action(self, user_id: int, skill_name: str) -> str:
        if skill_name not in SKILLS:
            return "Unknown skill."
        u = await self.dm.get_user(user_id)
        u["action"] = {"skill": skill_name, "last_tick": now_ts()}
        await self.dm.save()
        return f"Started **{skill_name}**!"

    async def stop_action(self, user_id: int) -> str:
        u = await self.dm.get_user(user_id)
        if not u.get("action"):
            return "No active action."
        skill = u["action"]["skill"]
        await self._apply_progress(user_id, u)  # finalize gains
        u["action"] = None
        await self.dm.save()
        return f"Stopped **{skill}**."

    async def _apply_progress(self, user_id: int, u: Dict[str, Any]) -> None:
        """Apply offline/idle progress since last_tick to inventory and XP."""
        action = u.get("action")
        if not action:
            return
        skill = action["skill"]
        last_tick = action.get("last_tick", now_ts())
        dt = max(0.0, now_ts() - last_tick)
        if dt < 0.5:
            return  # ignore tiny intervals

        skill_info = SKILLS[skill]
        xp_per_item = skill_info["xp_per_item"]
        resource = skill_info["resource"]
        level = level_from_xp(u["skills"][skill]["xp"])
        rate = self._rate_per_sec(skill, level, u["upgrades"].get(skill, 1))

        # How many actions happened during dt?
        actions = int(rate * dt)  # floor to whole items
        if actions <= 0:
            action["last_tick"] = now_ts()
            return

        if skill_info.get("type") == "process":
            # Consume inputs
            inputs = skill_info.get("input", {})
            max_by_inputs = min(u["inventory"].get(item, 0) // qty for item, qty in inputs.items())
            actions = min(actions, max_by_inputs)
            if actions <= 0:
                action["last_tick"] = now_ts()
                return
            for item, qty in inputs.items():
                u["inventory"][item] = max(0, u["inventory"].get(item, 0) - actions * qty)

        # Grant outputs
        u["inventory"][resource] = u["inventory"].get(resource, 0) + actions
        u["skills"][skill]["xp"] += actions * xp_per_item

        # Advance last_tick
        # Only consume the time that would produce the integer number of actions we applied
        seconds_used = actions / max(rate, 1e-9)
        action["last_tick"] = last_tick + seconds_used

    async def tick_user(self, user_id: int) -> None:
        u = await self.dm.get_user(user_id)
        await self._apply_progress(user_id, u)

    async def tick_all(self) -> None:
        for uid, u in await self.dm.get_all_users():
            await self._apply_progress(uid, u)
        await self.dm.save()

    async def sell_all(self, user_id: int) -> Tuple[int, Dict[str, int]]:
        u = await self.dm.get_user(user_id)
        await self._apply_progress(user_id, u)
        gold_gained = 0
        sold = {}
        sellable = {info["resource"]: info["value"] for info in SKILLS.values()}
        for item, count in list(u["inventory"].items()):
            if count > 0 and item in sellable:
                gold = sellable[item] * count
                gold_gained += gold
                sold[item] = count
                u["inventory"][item] = 0
        u["gold"] += gold_gained
        await self.dm.save()
        return gold_gained, sold

    async def buy_upgrade(self, user_id: int, skill_name: str) -> Tuple[bool, str]:
        u = await self.dm.get_user(user_id)
        await self._apply_progress(user_id, u)
        cur = u["upgrades"].get(skill_name, 1)
        cost = 100 * (cur ** 2)  # 1->2 costs 100; 2->3 costs 400; etc.
        if u["gold"] < cost:
            return False, f"Not enough gold. Need **{cost}**, you have **{u['gold']}**."
        u["gold"] -= cost
        u["upgrades"][skill_name] = cur + 1
        await self.dm.save()
        return True, f"Upgraded **{skill_name}** tool to **Lv.{cur+1}** (+10% speed)."

    async def profile_embed(self, user: discord.User, udata: Dict[str, Any]) -> discord.Embed:
        await self._apply_progress(user.id, udata)
        e = discord.Embed(title=f"{user.name}'s Profile", color=discord.Color.green())
        e.add_field(name="Gold", value=f"{udata['gold']:,}", inline=False)
        # Skills
        lines = []
        total_levels = 0
        for s in SKILLS.keys():
            xp = udata["skills"][s]["xp"]
            lvl = level_from_xp(xp)
            total_levels += lvl
            nxt = next_level_xp(lvl)
            cur = xp
            prev = xp_for_level(lvl)
            bar = progress_bar(cur - prev, max(1, nxt - prev))
            lines.append(f"**{s}** — Lv. **{lvl}**  {bar}  ({int(cur)}/{nxt} XP)  Tool Lv.{udata['upgrades'].get(s,1)}")
        e.add_field(name="Skills", value="\n".join(lines), inline=False)

        # Inventory summary (top few non-zero)
        inv = [f"{k} × {v}" for k, v in udata["inventory"].items() if v > 0]
        if inv:
            e.add_field(name="Inventory", value=", ".join(inv[:10]) + (" …" if len(inv) > 10 else ""), inline=False)
        action = udata.get("action")
        e.set_footer(text=f"Total Levels: {total_levels} | Active: {action['skill'] if action else 'None'}")
        return e

    async def inventory_embed(self, user: discord.User, udata: Dict[str, Any]) -> discord.Embed:
        await self._apply_progress(user.id, udata)
        e = discord.Embed(title=f"{user.name}'s Inventory", color=discord.Color.blurple())
        lines = [f"{item}: **{count}**" for item, count in udata["inventory"].items() if count > 0]
        e.description = "\n".join(lines) if lines else "_Empty._"
        return e

    async def leaderboard_embed(self, bot: commands.Bot) -> discord.Embed:
        users = await self.dm.get_all_users()
        ranks = []
        for uid, u in users:
            total = sum(level_from_xp(u["skills"][s]["xp"]) for s in SKILLS.keys())
            ranks.append((uid, total))
        ranks.sort(key=lambda t: t[1], reverse=True)
        e = discord.Embed(title="Global Leaderboard — Total Levels", color=discord.Color.gold())
        desc_lines = []
        for i, (uid, total) in enumerate(ranks[:10], start=1):
            member = bot.get_user(uid) or discord.Object(id=uid)
            name = getattr(member, "name", f"User {uid}")
            desc_lines.append(f"**#{i}** {name} — **{total}**")
        e.description = "\n".join(desc_lines) if desc_lines else "_No players yet._"
        return e

# ---------- Discord UI ----------
class SkillSelect(discord.ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(label=name, description=f"Train {name}", value=name)
            for name in SKILLS.keys()
        ]
        super().__init__(
            placeholder="Choose a skill to train…",
            min_values=1, max_values=1, options=options, custom_id="melvorcord:skill_select"
        )

    async def callback(self, interaction: discord.Interaction):
        assert interaction.user is not None
        view: "MainMenuView" = self.view  # type: ignore
        await view.engine.start_action(interaction.user.id, self.values[0])
        u = await view.dm.get_user(interaction.user.id)
        embed = await view.engine.profile_embed(interaction.user, u)
        await interaction.response.edit_message(embed=embed, view=view)

class MainMenuView(discord.ui.View):
    def __init__(self, dm: DataManager, engine: Engine, *, timeout: Optional[float] = None, persistent: bool = True):
        super().__init__(timeout=None if persistent else timeout)
        self.dm = dm
        self.engine = engine
        # Add components
        self.add_item(SkillSelect())

        self.btn_stop.custom_id = "melvorcord:stop"
        self.btn_profile.custom_id = "melvorcord:profile"
        self.btn_inventory.custom_id = "melvorcord:inventory"
        self.btn_sell.custom_id = "melvorcord:sellall"
        self.btn_upgrade.custom_id = "melvorcord:upgrade"
        self.btn_leaderboard.custom_id = "melvorcord:leaderboard"

    @discord.ui.button(label="Stop", style=discord.ButtonStyle.secondary, row=1)
    async def btn_stop(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.engine.stop_action(interaction.user.id)
        u = await self.dm.get_user(interaction.user.id)
        embed = await self.engine.profile_embed(interaction.user, u)
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(label="Profile", style=discord.ButtonStyle.primary, row=1)
    async def btn_profile(self, interaction: discord.Interaction, button: discord.ui.Button):
        u = await self.dm.get_user(interaction.user.id)
        embed = await self.engine.profile_embed(interaction.user, u)
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(label="Inventory", style=discord.ButtonStyle.primary, row=1)
    async def btn_inventory(self, interaction: discord.Interaction, button: discord.ui.Button):
        u = await self.dm.get_user(interaction.user.id)
        embed = await self.engine.inventory_embed(interaction.user, u)
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(label="Sell All", style=discord.ButtonStyle.danger, row=2)
    async def btn_sell(self, interaction: discord.Interaction, button: discord.ui.Button):
        gold, sold = await self.engine.sell_all(interaction.user.id)
        u = await self.dm.get_user(interaction.user.id)
        embed = await self.engine.profile_embed(interaction.user, u)
        if gold > 0:
            embed.add_field(name="Sold", value=", ".join(f"{k}×{v}" for k, v in sold.items()), inline=False)
            embed.add_field(name="Gold Gained", value=f"{gold}", inline=True)
        else:
            embed.add_field(name="Sold", value="_Nothing to sell._", inline=False)
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(label="Upgrade Tool", style=discord.ButtonStyle.success, row=2)
    async def btn_upgrade(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Upgrade the currently active skill, otherwise Woodcutting
        u = await self.dm.get_user(interaction.user.id)
        skill = (u.get("action") or {}).get("skill") or "Woodcutting"
        ok, msg = await self.engine.buy_upgrade(interaction.user.id, skill)
        embed = await self.engine.profile_embed(interaction.user, u)
        embed.add_field(name="Upgrade", value=msg, inline=False)
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(label="Leaderboard", style=discord.ButtonStyle.secondary, row=2)
    async def btn_leaderboard(self, interaction: discord.Interaction, button: discord.ui.Button):
        leaderboard = await self.engine.leaderboard_embed(interaction.client)  # type: ignore
        await interaction.response.edit_message(embed=leaderboard, view=self)

# ---------- Bot Setup ----------
intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)
dm = DataManager(DATA_PATH)
engine = Engine(dm)

@bot.event
async def on_ready():
    log.info("Logged in as %s (%s)", bot.user, bot.user.id if bot.user else "?")
    # Persistent view so buttons/selects continue to work after restart
    bot.add_view(MainMenuView(dm, engine, persistent=True))

    try:
        if GUILD_ID:
            guild = discord.Object(id=GUILD_ID)
            await bot.tree.sync(guild=guild)
            log.info("Synced slash commands to guild %s", GUILD_ID)
        else:
            await bot.tree.sync()
            log.info("Synced global slash commands.")
    except Exception:
        log.exception("Failed to sync app commands.")

@bot.tree.command(name="play", description="Open your idle menu.")
@app_commands.guilds(discord.Object(id=GUILD_ID)) if GUILD_ID else (lambda f: f)
async def play(interaction: discord.Interaction):
    await dm.load()
    u = await dm.get_user(interaction.user.id)
    embed = await engine.profile_embed(interaction.user, u)
    view = MainMenuView(dm, engine, persistent=True)
    # Post a fresh menu message in-channel
    await interaction.response.send_message(embed=embed, view=view)

@bot.tree.command(name="profile", description="Show your profile.")
@app_commands.guilds(discord.Object(id=GUILD_ID)) if GUILD_ID else (lambda f: f)
async def profile(interaction: discord.Interaction):
    u = await dm.get_user(interaction.user.id)
    embed = await engine.profile_embed(interaction.user, u)
    await interaction.response.send_message(embed=embed, ephemeral=True)

@bot.tree.command(name="leaderboard", description="Show the global leaderboard.")
@app_commands.guilds(discord.Object(id=GUILD_ID)) if GUILD_ID else (lambda f: f)
async def leaderboard_cmd(interaction: discord.Interaction):
    e = await engine.leaderboard_embed(bot)
    await interaction.response.send_message(embed=e, ephemeral=True)

# Background ticker to apply progress periodically for all users
@tasks.loop(seconds=60)
async def idle_tick():
    try:
        await engine.tick_all()
    except Exception:
        log.exception("idle_tick crashed")

@idle_tick.before_loop
async def before_idle():
    await bot.wait_until_ready()

idle_tick.start()

if __name__ == "__main__":
    if not TOKEN:
        log.error("Missing DISCORD_TOKEN environment variable. Set it and re-run.")
    else:
        bot.run(TOKEN)
