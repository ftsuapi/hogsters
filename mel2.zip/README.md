# Melvor-Style Idle Discord Bot (Starter Kit)

A Python `discord.py` bot that implements a Melvor Idle–inspired loop with embeds, buttons, and dropdown menus.
It includes a background tick, basic skills (Mining, Fishing, Woodcutting), simple combat, inventory, shop,
missions, and leaderboards—all persisted with SQLite.

## Quick Start

1. **Create a bot** at https://discord.com/developers/applications
2. Under *Bot* → *Privileged Gateway Intents*, enable:
   - **PRESENCE INTENT** (optional here)
   - **SERVER MEMBERS INTENT**
   - **MESSAGE CONTENT INTENT** ✅ *required for this starter*
3. Invite the bot to your server with the `applications.commands` scope.
4. **Install deps**:

```bash
python -m venv .venv && . .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

5. **Configure environment**:

```bash
# Powershell (Windows)
setx DISCORD_TOKEN "YOUR_BOT_TOKEN"

# bash/zsh (macOS/Linux)
export DISCORD_TOKEN="YOUR_BOT_TOKEN"
```

6. **Run**:
```bash
python main.py
```

## Features

- Main menu with **embeds**, **buttons**, and a **dropdown**.
- Skills: **Mining**, **Fishing**, **Woodcutting** (passive income via background tick).
- Simple **Combat**: Start/stop idling combat; earn loot, take damage, heal in town.
- **Inventory** & **Shop**: Buy/sell; coins and items tracked.
- **Missions** gated by player **level** (derived from total skill XP).
- **Leaderboards** (local server) for total XP and coins.
- Persistent **SQLite** database with aiosqlite, created on first run.
- Modular **cogs** for clean organization.

> This is a playable foundation you can extend with more skills, items, regions, bosses, and economy tuning.
