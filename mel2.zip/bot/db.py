import aiosqlite
import json
from contextlib import asynccontextmanager

SCHEMA = """
CREATE TABLE IF NOT EXISTS players (
  user_id INTEGER PRIMARY KEY,
  coins INTEGER NOT NULL DEFAULT 0,
  hp INTEGER NOT NULL DEFAULT 100,
  active_activity TEXT,
  activity_data TEXT
);
CREATE TABLE IF NOT EXISTS skills (
  user_id INTEGER NOT NULL,
  skill TEXT NOT NULL,
  xp INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, skill)
);
CREATE TABLE IF NOT EXISTS inventory (
  user_id INTEGER NOT NULL,
  item_id TEXT NOT NULL,
  qty INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, item_id)
);
"""

class Database:
    def __init__(self, path: str):
        self.path = path

    async def init(self):
        async with aiosqlite.connect(self.path) as conn:
            await conn.executescript(SCHEMA)
            await conn.commit()

    @asynccontextmanager
    async def connect(self):
        conn = await aiosqlite.connect(self.path)
        try:
            yield conn
        finally:
            await conn.close()

    async def ensure_player(self, user_id: int):
        async with self.connect() as conn:
            cur = await conn.execute("SELECT 1 FROM players WHERE user_id = ?", (user_id,))
            if await cur.fetchone() is None:
                await conn.execute("INSERT INTO players (user_id, coins, hp) VALUES (?, 0, 100)", (user_id,))
                # init baseline skills
                for s in ("mining","fishing","woodcutting","combat"):
                    await conn.execute("INSERT INTO skills (user_id, skill, xp) VALUES (?, ?, 0)", (user_id, s))
                await conn.commit()

    async def set_activity(self, user_id: int, activity: str|None, data: dict|None):
        data_json = json.dumps(data) if data else None
        async with self.connect() as conn:
            await conn.execute("UPDATE players SET active_activity=?, activity_data=? WHERE user_id=?",
                               (activity, data_json, user_id))
            await conn.commit()

    async def add_xp(self, user_id: int, skill: str, amount: int):
        async with self.connect() as conn:
            await conn.execute("UPDATE skills SET xp = xp + ? WHERE user_id=? AND skill=?", (amount, user_id, skill))
            await conn.commit()

    async def add_coins(self, user_id: int, amount: int):
        async with self.connect() as conn:
            await conn.execute("UPDATE players SET coins = coins + ? WHERE user_id=?", (amount, user_id))
            await conn.commit()

    async def get_coins(self, user_id: int) -> int:
        async with self.connect() as conn:
            cur = await conn.execute("SELECT coins FROM players WHERE user_id=?", (user_id,))
            row = await cur.fetchone()
            return row[0] if row else 0

    async def add_item(self, user_id: int, item_id: str, qty: int):
        async with self.connect() as conn:
            await conn.execute("""
                INSERT INTO inventory (user_id, item_id, qty) VALUES (?, ?, ?)
                ON CONFLICT(user_id, item_id) DO UPDATE SET qty = qty + excluded.qty
            """, (user_id, item_id, qty))
            await conn.commit()

    async def get_inventory(self, user_id: int):
        async with self.connect() as conn:
            cur = await conn.execute("SELECT item_id, qty FROM inventory WHERE user_id=? AND qty > 0", (user_id,))
            return await cur.fetchall()

    async def add_hp(self, user_id: int, delta: int):
        async with self.connect() as conn:
            await conn.execute("UPDATE players SET hp = max(0, min(100, hp + ?)) WHERE user_id=?", (delta, user_id))
            await conn.commit()

    async def set_hp(self, user_id: int, value: int):
        async with self.connect() as conn:
            await conn.execute("UPDATE players SET hp = ?", (value,))
            await conn.commit()

    async def get_hp(self, user_id: int) -> int:
        async with self.connect() as conn:
            cur = await conn.execute("SELECT hp FROM players WHERE user_id=?", (user_id,))
            row = await cur.fetchone()
            return row[0] if row else 100

    async def top_xp(self, limit: int = 10):
        query = """
        SELECT p.user_id, SUM(s.xp) as total_xp
        FROM players p
        JOIN skills s ON s.user_id = p.user_id
        GROUP BY p.user_id
        ORDER BY total_xp DESC
        LIMIT ?
        """
        async with self.connect() as conn:
            cur = await conn.execute(query, (limit,))
            return await cur.fetchall()

    async def top_coins(self, limit: int = 10):
        async with self.connect() as conn:
            cur = await conn.execute("SELECT user_id, coins FROM players ORDER BY coins DESC LIMIT ?", (limit,))
            return await cur.fetchall()
