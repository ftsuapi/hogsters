def xp_to_level(xp: int) -> int:
    # basic curve similar to RS (short list, cap 99 in real game)
    thresholds = [0, 83, 174, 276, 388, 512, 650, 801, 969, 1154, 1358, 1584, 1833, 2107, 2411, 2746]
    lvl = 1
    for i, t in enumerate(thresholds, start=1):
        if xp >= t:
            lvl = i
    return min(lvl, 99)
