import discord
from discord.ext import commands
from .db import Database
from .utils import xp_to_level

def menu_embed(user: discord.User) -> discord.Embed:
    e = discord.Embed(title="🏝️ Idle Realms", description="Melvor-style idle bot • Use the buttons below", color=discord.Color.blurple())
    e.set_author(name=user.display_name, icon_url=user.display_avatar.url if user.display_avatar else discord.Embed.Empty)
    e.add_field(name="Quick cmds", value="`!start mining|fishing|woodcutting|combat` · `!stop` · `!heal`", inline=False)
    e.set_footer(text="Tip: keep this message pinned as your hub")
    return e

class MainMenuView(discord.ui.View):
    def __init__(self, db: Database, user_id: int, timeout: float | None = 120):
        super().__init__(timeout=timeout)
        self.db = db
        self.user_id = user_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        return interaction.user and interaction.user.id == self.user_id

    @discord.ui.button(label="Profile", style=discord.ButtonStyle.primary, emoji="🧙")
    async def profile_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        coins = await self.db.get_coins(self.user_id)
        hp = await self.db.get_hp(self.user_id)
        # Sum XP
        async with self.db.connect() as conn:
            cur = await conn.execute("SELECT skill, xp FROM skills WHERE user_id=?", (self.user_id,))
            rows = await cur.fetchall()
        total_xp = sum(x for _, x in rows)
        level = xp_to_level(total_xp)
        e = discord.Embed(title="📜 Profile", color=discord.Color.gold())
        e.add_field(name="Level", value=str(level))
        e.add_field(name="HP", value=f"{hp}/100")
        e.add_field(name="Coins", value=str(coins))
        if rows:
            skills = "\n".join(f"• {s.title()}: {xp} xp" for s, xp in rows)
            e.add_field(name="Skills", value=skills, inline=False)
        await interaction.response.edit_message(embed=e, view=self)

    @discord.ui.button(label="Inventory", style=discord.ButtonStyle.secondary, emoji="🎒")
    async def inv_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        items = await self.db.get_inventory(self.user_id)
        desc = "\n".join(f"• {i}: {q}" for i, q in items) if items else "Empty"
        e = discord.Embed(title="🎒 Inventory", description=desc, color=discord.Color.dark_teal())
        await interaction.response.edit_message(embed=e, view=self)

    @discord.ui.button(label="Shop", style=discord.ButtonStyle.secondary, emoji="🏪")
    async def shop_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Simple shop list
        e = discord.Embed(title="🏪 Shop", description="Buy items with coins", color=discord.Color.green())
        e.add_field(name="Items", value="• Health Potion (10)\n• Pickaxe (50)\n• Rod (50)\n• Axe (50)")
        await interaction.response.edit_message(embed=e, view=ShopView(self.db, self.user_id))

    @discord.ui.button(label="Missions", style=discord.ButtonStyle.secondary, emoji="🗺️")
    async def missions_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Level-gated missions: 1, 5, 10
        async with self.db.connect() as conn:
            cur = await conn.execute("SELECT xp FROM skills WHERE user_id=?", (self.user_id,))
            total_xp = sum(x for (x,) in await cur.fetchall())
        lvl = xp_to_level(total_xp)
        options = [
            discord.SelectOption(label="Gathering Run", description="Easy — 5m", value="gather", emoji="🪓"),
        ]
        if lvl >= 5:
            options.append(discord.SelectOption(label="Scout Woods", description="Medium — 10m", value="scout", emoji="🌲"))
        if lvl >= 10:
            options.append(discord.SelectOption(label="Cave Dive", description="Hard — 15m", value="cave", emoji="🕳️"))
        e = discord.Embed(title="🗺️ Missions", description=f"Your level: **{lvl}**", color=discord.Color.purple())
        v = MissionView(self.db, self.user_id, options)
        await interaction.response.edit_message(embed=e, view=v)

    @discord.ui.button(label="Leaderboard", style=discord.ButtonStyle.secondary, emoji="🏆")
    async def lb_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        topx = await self.db.top_xp(10)
        topc = await self.db.top_coins(10)
        def fmt(entries):
            return "\n".join(f"{i+1}. <@{uid}> — {val}" for i, (uid, val) in enumerate(entries)) or "No data yet."
        e = discord.Embed(title="🏆 Leaderboards", color=discord.Color.orange())
        e.add_field(name="Top XP", value=fmt(topx), inline=False)
        e.add_field(name="Top Coins", value=fmt(topc), inline=False)
        await interaction.response.edit_message(embed=e, view=self)

    @discord.ui.button(label="Gather", style=discord.ButtonStyle.success, emoji="⛏️")
    async def gather_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        e = discord.Embed(title="⛏️ Gathering", description="Choose a skill to idle:", color=discord.Color.blurple())
        await interaction.response.edit_message(embed=e, view=GatherView(self.db, self.user_id))

    @discord.ui.button(label="Combat", style=discord.ButtonStyle.danger, emoji="⚔️")
    async def combat_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        hp = await self.db.get_hp(self.user_id)
        e = discord.Embed(title="⚔️ Combat", description=f"HP: **{hp}/100** • Use buttons to start/stop", color=discord.Color.red())
        await interaction.response.edit_message(embed=e, view=CombatView(self.db, self.user_id))

    @discord.ui.button(label="Return to Main", style=discord.ButtonStyle.secondary, emoji="🏠")
    async def back_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(embed=menu_embed(interaction.user), view=self)

class GatherView(discord.ui.View):
    def __init__(self, db: Database, user_id: int):
        super().__init__(timeout=120)
        self.db = db
        self.user_id = user_id

    @discord.ui.select(placeholder="Pick a skill to idle…", options=[
        discord.SelectOption(label="Mining", value="mining", emoji="⛏️"),
        discord.SelectOption(label="Fishing", value="fishing", emoji="🎣"),
        discord.SelectOption(label="Woodcutting", value="woodcutting", emoji="🪓"),
    ])
    async def select_skill(self, interaction: discord.Interaction, select: discord.ui.Select):
        choice = select.values[0]
        await self.db.set_activity(self.user_id, choice, None)
        await interaction.response.edit_message(embed=discord.Embed(title="✅ Started", description=f"Now idling **{choice}**. Use `!stop` to stop."), view=self)

    @discord.ui.button(label="⬅ Back", style=discord.ButtonStyle.secondary)
    async def back(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(embed=menu_embed(interaction.user), view=MainMenuView(self.db, self.user_id))

class CombatView(discord.ui.View):
    def __init__(self, db: Database, user_id: int):
        super().__init__(timeout=120)
        self.db = db
        self.user_id = user_id

    @discord.ui.button(label="Start Combat", style=discord.ButtonStyle.danger, emoji="⚔️")
    async def start(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.db.set_activity(self.user_id, "combat", None)
        await interaction.response.edit_message(embed=discord.Embed(title="⚔️ Combat", description="Now idling combat. `!stop` to stop."), view=self)

    @discord.ui.button(label="Stop", style=discord.ButtonStyle.secondary)
    async def stop(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.db.set_activity(self.user_id, None, None)
        await interaction.response.edit_message(embed=discord.Embed(title="🛑 Stopped", description="Combat stopped."), view=self)

    @discord.ui.button(label="⬅ Back", style=discord.ButtonStyle.secondary)
    async def back(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(embed=menu_embed(interaction.user), view=MainMenuView(self.db, self.user_id))

class ShopView(discord.ui.View):
    def __init__(self, db: Database, user_id: int):
        super().__init__(timeout=120)
        self.db = db
        self.user_id = user_id

    @discord.ui.select(placeholder="Buy an item…", options=[
        discord.SelectOption(label="Health Potion (10)", value="potion"),
        discord.SelectOption(label="Pickaxe (50)", value="pickaxe"),
        discord.SelectOption(label="Rod (50)", value="rod"),
        discord.SelectOption(label="Axe (50)", value="axe"),
    ])
    async def buy(self, interaction: discord.Interaction, select: discord.ui.Select):
        prices = {"potion":10, "pickaxe":50, "rod":50, "axe":50}
        item = select.values[0]
        price = prices[item]
        coins = await self.db.get_coins(self.user_id)
        if coins < price:
            return await interaction.response.edit_message(embed=discord.Embed(title="❌ Not enough coins", description=f"You need {price}."), view=self)
        await self.db.add_coins(self.user_id, -price)
        await self.db.add_item(self.user_id, item, 1)
        await interaction.response.edit_message(embed=discord.Embed(title="✅ Purchased", description=f"You bought **{item}** for {price}."), view=self)

    @discord.ui.button(label="⬅ Back", style=discord.ButtonStyle.secondary)
    async def back(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(embed=menu_embed(interaction.user), view=MainMenuView(self.db, self.user_id))

class MissionView(discord.ui.View):
    def __init__(self, db: Database, user_id: int, options: list[discord.SelectOption]):
        super().__init__(timeout=120)
        self.db = db
        self.user_id = user_id
        self._select = discord.ui.Select(placeholder="Choose a mission…", options=options, min_values=1, max_values=1)
        self._select.callback = self._run
        self.add_item(self._select)

    async def _run(self, interaction: discord.Interaction):
        choice = self._select.values[0]
        # For demo, missions simply grant a lump sum immediately.
        rewards = {
            "gather": (25, 5),
            "scout": (60, 20),
            "cave": (140, 50),
        }
        xp, coins = rewards.get(choice, (10, 2))
        await self.db.add_xp(self.user_id, "mining", xp//3)
        await self.db.add_xp(self.user_id, "fishing", xp//3)
        await self.db.add_xp(self.user_id, "woodcutting", xp//3)
        await self.db.add_coins(self.user_id, coins)
        await interaction.response.edit_message(embed=discord.Embed(title="🎉 Mission Complete", description=f"Gained **{xp} xp** split across gathering and **{coins}** coins."))

        # keep the same view so user can run more or go back
        self._select.disabled = False
        await interaction.edit_original_response(view=self)

    @discord.ui.button(label="⬅ Back", style=discord.ButtonStyle.secondary)
    async def back(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(embed=menu_embed(interaction.user), view=MainMenuView(self.db, self.user_id))
