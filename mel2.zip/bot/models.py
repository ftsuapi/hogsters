from .db import Database

async def ensure_player(db: Database, user_id: int):
    await db.ensure_player(user_id)

def level_from_xp(xp: int) -> int:
    # RuneScape-like curve (very simplified)
    lvl = 1
    thresholds = [0, 83, 174, 276, 388, 512, 650, 801, 969, 1154, 1358, 1584, 1833, 2107, 2411, 2746]
    for i, t in enumerate(thresholds, start=1):
        if xp >= t:
            lvl = i
    return min(lvl, 99)
