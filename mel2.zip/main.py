import os
import asyncio
import discord
from discord.ext import commands, tasks
from bot.db import Database
from bot.models import ensure_player
from bot.views import MainMenuView, menu_embed
from bot.utils import xp_to_level

INTENTS = discord.Intents.default()
INTENTS.message_content = True
INTENTS.guilds = True
INTENTS.members = True

PREFIX = "!"

class IdleBot(commands.Bot):
    def __init__(self):
        super().__init__(command_prefix=PREFIX, intents=INTENTS, help_command=None)
        self.db = Database("data/game.db")
        self.tick_seconds = 5  # global idle tick
        self.game_tick.start()

    async def setup_hook(self):
        # Load cogs here if you split more features; this starter keeps it compact.
        pass

    async def on_ready(self):
        print(f"Logged in as {self.user} (ID: {self.user.id})")
        await self.db.init()
        await self.change_presence(activity=discord.Game(name="Idle adventures | !menu"))
    
    @tasks.loop(seconds=5.0)
    async def game_tick(self):
        # Distribute passive yields to players who have an active skill/combat
        try:
            async with self.db.connect() as conn:
                users = await conn.execute_fetchall("SELECT user_id, active_activity, activity_data FROM players")
                for user_id, activity, data_json in users:
                    if not activity:
                        continue
                    data = {}
                    if data_json:
                        import json
                        data = json.loads(data_json)
                    # Simple activities: mining, fishing, woodcutting, combat
                    gains = 0
                    hp_change = 0
                    items = []
                    if activity in ("mining", "fishing", "woodcutting"):
                        gains = 5  # xp
                        items.append((activity+"_loot", 1, 1))  # (item_id, qty, chance)
                        await self.db.add_xp(user_id, activity, gains)
                        await self.db.add_item(user_id, f"{activity}_log" if activity=="woodcutting" else f"{activity}_raw", 1)
                    elif activity == "combat":
                        # trivial combat loop for demo
                        await self.db.add_xp(user_id, "combat", 7)
                        await self.db.add_item(user_id, "bone", 1)
                        # take a bit of damage, auto-fail if hp <= 0
                        await self.db.add_hp(user_id, -2)
                        hp = await self.db.get_hp(user_id)
                        if hp <= 0:
                            await self.db.set_activity(user_id, None, None)
                    # coins drip (global)
                    await self.db.add_coins(user_id, 1)
        except Exception as e:
            print("Tick error:", e)

    @game_tick.before_loop
    async def before_tick(self):
        await self.wait_until_ready()

bot = IdleBot()

@bot.command(name="menu")
async def menu(ctx: commands.Context):
    """Show the main menu embed with buttons/selects."""
    await ensure_player(bot.db, ctx.author.id)
    view = MainMenuView(bot.db, ctx.author.id)
    await ctx.reply(embed=menu_embed(ctx.author), view=view, mention_author=False)

@bot.command(name="start")
async def start_skill(ctx: commands.Context, skill: str):
    """Start an activity: mining/fishing/woodcutting/combat"""
    await ensure_player(bot.db, ctx.author.id)
    skill = skill.lower()
    if skill not in ("mining", "fishing", "woodcutting", "combat"):
        return await ctx.reply("Valid activities: mining, fishing, woodcutting, combat")
    await bot.db.set_activity(ctx.author.id, skill, None)
    await ctx.reply(f"Started **{skill}**. Use `!stop` to stop.")

@bot.command(name="stop")
async def stop_skill(ctx: commands.Context):
    await ensure_player(bot.db, ctx.author.id)
    await bot.db.set_activity(ctx.author.id, None, None)
    await ctx.reply("Stopped current activity.")

@bot.command(name="heal")
async def heal(ctx: commands.Context):
    await ensure_player(bot.db, ctx.author.id)
    cost = 5
    coins = await bot.db.get_coins(ctx.author.id)
    if coins < cost:
        return await ctx.reply("Not enough coins to heal (5).")
    await bot.db.add_coins(ctx.author.id, -cost)
    await bot.db.set_hp(ctx.author.id, 100)
    await ctx.reply("You are fully healed! 💖")

@bot.command(name="invite")
async def invite(ctx: commands.Context):
    app_info = await bot.application_info()
    await ctx.reply(f"Invite me with slash perms: https://discord.com/api/oauth2/authorize?client_id={app_info.id}&permissions=412317196288&scope=bot%20applications.commands")

def main():
    token = os.getenv("DISCORD_TOKEN")
    if not token:
        raise RuntimeError("Set DISCORD_TOKEN env var.")
    bot.run(token)

if __name__ == "__main__":
    main()
