# HOGSTERS (Discord Bot Game)

HOGSTERS is a Mobsters-style Discord game with embeds, buttons, and dropdowns.
It features Missions, Shop, Profile, Properties, Businesses, and PvP with persistent SQLite.

## Quick Start

1. Create a Discord bot in the Developer Portal and copy the token.
2. Put your token in a file named `.env` in this folder:

```
DISCORD_TOKEN=your_bot_token_here
```

3. Install Python 3.10+ (3.11+ recommended), then:

**Windows (PowerShell):**
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -U discord.py aiosqlite python-dotenv
python main.py
```

**macOS / Linux:**
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -U discord.py aiosqlite python-dotenv
python main.py
```

4. In your server, run `/menu` to open the HOGSTERS HQ.

## Features
- Missions with level gates, energy cost, chance-based rewards
- Shop (weapons/armor/consumables)
- Properties (hourly income) and Businesses (multi-hour cycles)
- PvP with target selection, cooldowns, cash steals, respect/heat
- Persistent data in `hogsters.db`

## Notes
- Energy regenerates 1/min up to 30.
- PvP has a short cooldown (45s) for testing.
- Delete `hogsters.db` to reset content seeds and progress.
