import os
import random
import asyncio
import aiosqlite
import datetime as dt
from typing import Optional, Dict, Any, List

import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

# ----------------- Setup -----------------
load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")

INTENTS = discord.Intents.default()
INTENTS.message_content = True
INTENTS.members = True  # for PvP target selection

DB_PATH = "hogsters.db"

# ----------------- Content -----------------
# Items: id, name, type, min_lvl, cost, atk, def, hp_bonus, notes, rarity
ITEMS = [
    (1, "Rusty Tusk Shiv",  "weapon", 1, 150,   3, 0,  0,  "Starter squeal-steel", "common"),
    (2, "Brass Tusks",      "weapon", 3, 900,   8, 0,  0,  "Crit +1%", "common"),
    (3, "Boar Plate",       "armor",  5, 2500,  0, 8,  5,  "Hide-hardened plate", "uncommon"),
    (4, "Hog Hammer",       "weapon", 6, 3500,  16,0,  0,  "Stun 5%", "uncommon"),
    (5, "Kevlar Vestlet",   "armor",  8, 8000,  0, 16, 10, "Snoutgun stopper-ish", "rare"),
    (6, "Bacon Roll",       "consumable", 1, 50, 0, 0, 0, "Heal +20 HP", "common"),
    (7, "Energy Shot",      "consumable", 4, 200, 0,0,0,  "+10 Energy", "common"),
    (8, "Serrated Tusker",  "weapon", 9, 9000,  28,0,0,   "Bleed 5%", "rare"),
    (9, "Reinforced Hogplate","armor",12, 18000,0,22,15,  "Takes a truffle-beating", "rare"),
    (10,"Snout SMG",        "weapon", 15, 35000, 58,0,0,  "Multi-hit 5%", "epic"),
    (11,"Gilded Hogplate",  "armor",  18, 65000, 0,40,25, "Shiny & sturdy", "epic"),
    (12,"Adrenaline Boarst","consumable",10,1200,0,0,0,  "+15% ATK (10m)", "uncommon"),
    (13,"Smoke Truffle",    "consumable",14,1600,0,0,0,  "-2 Heat", "uncommon"),
    (14,"Razorback Rifle",  "weapon", 20, 75000, 85,0,0, "Crit +3%", "epic"),
    (15,"Syndicate Riot Gear","armor",24, 120000,0,60,35,"Business-approved bash-proof", "epic"),
    (16,"Golden Snout",     "consumable",28,12000,0,0,0, "+5% rare drop (30m)", "legendary"),
    (17,"Ivory Cannon",     "weapon", 30, 300000,170,0,0,"Armor pierce", "legendary"),
    (18,"Velvet Boarcoat",  "armor",  32, 180000,0,95,45,"Ridiculously fashionable", "legendary"),
]

# Missions: id, name, min_lvl, energy_cost, time_sec, success_pct, cash_min, cash_max, xp_min, xp_max, heat_add
MISSIONS = [
    (1, "Alley Trot",           1,  5, 10, 90,   60,  90,  12, 18, 0),
    (2, "Stash Snuffle",        3,  7, 20, 85,  120, 180,  20, 30, 0),
    (3, "Fence the Goods",      6, 10, 35, 80,  220, 330,  35, 55, 1),
    (4, "Distract the Boar-lice", 9,12,45, 78,  320, 480,  50, 80, 2),
    (5, "Raid the Depot",      12, 15, 60, 74,  480, 720,  70,110, 3),
    (6, "Heist the Railcar",   16, 18, 75, 70,  700,1000, 100,150, 4),
    (7, "Syndicate Hit",       22, 22, 90, 66, 1100,1600, 140,210, 5),
    (8, "Velvet Vault Job",    28, 26,120, 62, 1700,2400, 200,300, 6),
    (9, "Gilt Gallery Lift",   32, 30,150, 58, 2400,3200, 260,360, 7),
    (10,"Harbor Night Run",    36, 34,180, 55, 3200,4200, 320,440, 8),
]

# Properties: id, name, min_level, buy_cost, base_income_per_hour, upkeep_per_hour, upgrade_level_max
PROPERTIES = [
    (1, "Back-Alley Stall", 4, 2000, 120, 10, 5),
    (2, "Chop Shop Bay", 8, 9000, 540, 70, 5),
    (3, "Speakeasy Booth", 12, 18000, 1120, 140, 5),
    (4, "Truffle Farm Plot", 16, 35000, 2300, 280, 5),
    (5, "Hog Hauling Route", 20, 60000, 3900, 480, 5),
    (6, "Syndicate Warehouse", 26, 120000, 7800, 980, 5),
]

# Businesses: id, name, min_level, buy_cost, cycle_hours, payout_min, payout_max, upkeep_per_cycle, risk(1-3)
BUSINESSES = [
    (1, "Pawn Syndicate", 10, 25000, 4, 6500, 9000, 800, 1),
    (2, "Black Truffle Cartel", 18, 80000, 6, 22000, 30000, 2600, 2),
    (3, "Hog Transit Co.", 24, 150000, 8, 40000, 60000, 5200, 2),
    (4, "Velvet Nightclubs", 30, 320000, 12, 100000, 140000, 12000, 3),
]

# ----------------- Schema -----------------
CREATE_SQL: List[str] = [
    """CREATE TABLE IF NOT EXISTS players(
        player_id INTEGER,
        guild_id INTEGER,
        name TEXT,
        level INTEGER DEFAULT 1,
        xp INTEGER DEFAULT 0,
        hp INTEGER DEFAULT 100,
        energy INTEGER DEFAULT 30,
        attack INTEGER DEFAULT 5,
        defense INTEGER DEFAULT 5,
        strength INTEGER DEFAULT 3,
        agility INTEGER DEFAULT 3,
        luck INTEGER DEFAULT 1,
        cash INTEGER DEFAULT 200,
        bank INTEGER DEFAULT 0,
        respect INTEGER DEFAULT 0,
        heat INTEGER DEFAULT 0,
        last_energy_at TEXT,
        PRIMARY KEY(player_id, guild_id)
    );""",
    """CREATE TABLE IF NOT EXISTS items(
        id INTEGER PRIMARY KEY,
        name TEXT,
        type TEXT,
        min_level INTEGER,
        cost INTEGER,
        atk INTEGER,
        def INTEGER,
        hp_bonus INTEGER,
        notes TEXT,
        rarity TEXT
    );""",
    """CREATE TABLE IF NOT EXISTS inventory(
        player_id INTEGER,
        guild_id INTEGER,
        item_id INTEGER,
        qty INTEGER DEFAULT 0,
        equipped INTEGER DEFAULT 0,
        PRIMARY KEY(player_id, guild_id, item_id)
    );""",
    """CREATE TABLE IF NOT EXISTS missions(
        id INTEGER PRIMARY KEY,
        name TEXT,
        min_level INTEGER,
        energy_cost INTEGER,
        time_sec INTEGER,
        success_pct INTEGER,
        cash_min INTEGER,
        cash_max INTEGER,
        xp_min INTEGER,
        xp_max INTEGER,
        heat_add INTEGER
    );""",
    """CREATE TABLE IF NOT EXISTS cooldowns(
        player_id INTEGER,
        guild_id INTEGER,
        action TEXT,
        ready_at TEXT,
        PRIMARY KEY(player_id, guild_id, action)
    );""",
    """CREATE TABLE IF NOT EXISTS properties(
        id INTEGER PRIMARY KEY,
        name TEXT,
        min_level INTEGER,
        buy_cost INTEGER,
        base_income INTEGER,
        upkeep INTEGER,
        upgrade_level_max INTEGER
    );""",
    """CREATE TABLE IF NOT EXISTS player_properties(
        player_id INTEGER,
        guild_id INTEGER,
        property_id INTEGER,
        level INTEGER DEFAULT 1,
        last_collected_at TEXT,
        PRIMARY KEY(player_id, guild_id, property_id)
    );""",
    """CREATE TABLE IF NOT EXISTS businesses(
        id INTEGER PRIMARY KEY,
        name TEXT,
        min_level INTEGER,
        buy_cost INTEGER,
        cycle_hours INTEGER,
        payout_min INTEGER,
        payout_max INTEGER,
        upkeep_per_cycle INTEGER,
        risk INTEGER
    );""",
    """CREATE TABLE IF NOT EXISTS player_businesses(
        player_id INTEGER,
        guild_id INTEGER,
        business_id INTEGER,
        level INTEGER DEFAULT 1,
        last_cycle_at TEXT,
        PRIMARY KEY(player_id, guild_id, business_id)
    );""",
    """CREATE TABLE IF NOT EXISTS fights(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        attacker_id INTEGER,
        defender_id INTEGER,
        guild_id INTEGER,
        result TEXT,
        cash_delta INTEGER,
        created_at TEXT
    );""",
]

async def db_init():
    async with aiosqlite.connect(DB_PATH) as db:
        for sql in CREATE_SQL:
            await db.execute(sql)
        # seeds
        for row in ITEMS:
            await db.execute("""INSERT OR IGNORE INTO items
                (id,name,type,min_level,cost,atk,def,hp_bonus,notes,rarity)
                VALUES(?,?,?,?,?,?,?,?,?,?)""", row)
        for row in MISSIONS:
            await db.execute("""INSERT OR IGNORE INTO missions
                (id,name,min_level,energy_cost,time_sec,success_pct,cash_min,cash_max,xp_min,xp_max,heat_add)
                VALUES(?,?,?,?,?,?,?,?,?,?,?)""", row)
        for row in PROPERTIES:
            await db.execute("""INSERT OR IGNORE INTO properties
                (id,name,min_level,buy_cost,base_income,upkeep,upgrade_level_max)
                VALUES(?,?,?,?,?,?,?)""", row)
        for row in BUSINESSES:
            await db.execute("""INSERT OR IGNORE INTO businesses
                (id,name,min_level,buy_cost,cycle_hours,payout_min,payout_max,upkeep_per_cycle,risk)
                VALUES(?,?,?,?,?,?,?,?,?)""", row)
        await db.commit()

# ----------------- Helpers -----------------
def xp_to_next(level: int) -> int:
    return round(50 * (level ** 1.5))

def now_iso() -> str:
    return dt.datetime.utcnow().isoformat()

def hours_since(iso_time: Optional[str]) -> float:
    if not iso_time:
        return 0.0
    then = dt.datetime.fromisoformat(iso_time)
    return (dt.datetime.utcnow() - then).total_seconds() / 3600.0

def cycles_elapsed(iso_time: Optional[str], cycle_hours: int) -> int:
    if not iso_time:
        return 1
    return int(hours_since(iso_time) // cycle_hours)

def property_income_for_hours(base_income: int, upkeep: int, level: int, hours: float) -> int:
    mult = 1.0 + 0.25 * (level - 1)
    gross = base_income * mult * hours
    cost = (upkeep * level) * hours
    return max(0, int(round(gross - cost)))

async def get_player(db, player_id: int, guild_id: int, name: str) -> Dict[str, Any]:
    cur = await db.execute("SELECT * FROM players WHERE player_id=? AND guild_id=?", (player_id, guild_id))
    row = await cur.fetchone()
    if row:
        cols = [c[0] for c in cur.description]
        return dict(zip(cols, row))
    await db.execute("""INSERT INTO players(player_id,guild_id,name,last_energy_at)
                        VALUES(?,?,?,?)""", (player_id, guild_id, name, now_iso()))
    await db.commit()
    return await get_player(db, player_id, guild_id, name)

async def save_player(db, p: Dict[str, Any]):
    await db.execute("""UPDATE players SET
                        level=?, xp=?, hp=?, energy=?, attack=?, defense=?,
                        strength=?, agility=?, luck=?, cash=?, bank=?,
                        respect=?, heat=?, last_energy_at=?
                        WHERE player_id=? AND guild_id=?""",
                     (p["level"], p["xp"], p["hp"], p["energy"], p["attack"], p["defense"],
                      p["strength"], p["agility"], p["luck"], p["cash"], p["bank"],
                      p["respect"], p["heat"], p["last_energy_at"],
                      p["player_id"], p["guild_id"]))
    await db.commit()

async def regen_energy(db, player: Dict[str, Any], per_min: int = 1, cap: int = 30):
    last = player["last_energy_at"]
    last_dt = dt.datetime.fromisoformat(last) if last else dt.datetime.utcnow()
    now = dt.datetime.utcnow()
    minutes = int((now - last_dt).total_seconds() // 60)
    if minutes > 0 and player["energy"] < cap:
        player["energy"] = min(cap, player["energy"] + minutes * per_min)
        player["last_energy_at"] = now.isoformat()
        await save_player(db, player)

async def get_cd(db, player_id: int, guild_id: int, action: str) -> float:
    cur = await db.execute("""SELECT ready_at FROM cooldowns
                              WHERE player_id=? AND guild_id=? AND action=?""",
                           (player_id, guild_id, action))
    row = await cur.fetchone()
    if not row or not row[0]:
        return 0.0
    ready = dt.datetime.fromisoformat(row[0])
    return max(0.0, (ready - dt.datetime.utcnow()).total_seconds())

async def set_cd(db, player_id: int, guild_id: int, action: str, seconds: int):
    ready_at = (dt.datetime.utcnow() + dt.timedelta(seconds=seconds)).isoformat()
    await db.execute("""INSERT INTO cooldowns(player_id,guild_id,action,ready_at)
                        VALUES(?,?,?,?)
                        ON CONFLICT(player_id,guild_id,action) DO UPDATE SET ready_at=excluded.ready_at""",
                     (player_id, guild_id, action, ready_at))
    await db.commit()

# ----------------- Bot -----------------
class Hogsters(commands.Bot):
    def __init__(self):
        super().__init__(command_prefix="!", intents=INTENTS)
        self.tree = app_commands.CommandTree(self)

    async def setup_hook(self):
        await db_init()
        await self.tree.sync()

bot = Hogsters()

# ----------------- Views & UI -----------------
class MainMenu(discord.ui.View):
    def __init__(self, user: discord.abc.User):
        super().__init__(timeout=180)
        self.user = user

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user.id:
            await interaction.response.send_message("❌ Hoof off! That’s not your menu.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Missions", style=discord.ButtonStyle.green, emoji="🎯")
    async def missions(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_missions(interaction)

    @discord.ui.button(label="Shop", style=discord.ButtonStyle.blurple, emoji="🏪")
    async def shop(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_shop(interaction)

    @discord.ui.button(label="Properties", style=discord.ButtonStyle.green, emoji="🏠")
    async def properties(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_properties(interaction)

    @discord.ui.button(label="Businesses", style=discord.ButtonStyle.green, emoji="🏭")
    async def businesses(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_businesses(interaction)

    @discord.ui.button(label="Fight", style=discord.ButtonStyle.red, emoji="⚔️")
    async def fight(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_fight(interaction)

    @discord.ui.button(label="Profile", style=discord.ButtonStyle.gray, emoji="📊")
    async def profile(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_profile(interaction)

# ---- Missions ----
class MissionSelect(discord.ui.Select):
    def __init__(self, missions: List[Dict[str, Any]]):
        options = [
            discord.SelectOption(
                label=f"{m['name']} (Lv{m['min_level']})",
                description=f"Energy {m['energy_cost']} • ~{m['time_sec']}s • {m['success_pct']}% squeal-cess",
                value=str(m["id"])
            ) for m in missions
        ]
        super().__init__(placeholder="Pick a mission, pig-styler…", options=options, min_values=1, max_values=1)

    async def callback(self, interaction: discord.Interaction):
        mission_id = int(self.values[0])
        await start_mission_prompt(interaction, mission_id)

class MissionView(discord.ui.View):
    def __init__(self, missions: List[Dict[str, Any]]):
        super().__init__(timeout=180)
        self.add_item(MissionSelect(missions))

async def show_missions(interaction: discord.Interaction):
    async with aiosqlite.connect(DB_PATH) as db:
        p = await get_player(db, interaction.user.id, interaction.guild_id, interaction.user.display_name)
        await regen_energy(db, p)
        cur = await db.execute("SELECT * FROM missions ORDER BY min_level ASC")
        rows = await cur.fetchall()
        cols = [c[0] for c in cur.description]
        missions = [dict(zip(cols, r)) for r in rows if p['level'] >= r[2]]

    if not missions:
        embed = discord.Embed(title="🐽 Missions", description="You’re too green of a hog. Oink up a few levels first!", color=discord.Color.green())
        await interaction.response.edit_message(embed=embed, view=None)
        return

    embed = discord.Embed(
        title="🎯 Hog-Operations Board",
        description="Select your squeal-destiny from the dropdown below.",
        color=discord.Color.green()
    )
    embed.set_footer(text=f"Energy: {p['energy']} • Level: {p['level']}")
    view = MissionView(missions)
    await interaction.response.edit_message(embed=embed, view=view)

async def start_mission_prompt(interaction: discord.Interaction, mission_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        p = await get_player(db, interaction.user.id, interaction.guild_id, interaction.user.display_name)
        await regen_energy(db, p)
        cur = await db.execute("SELECT * FROM missions WHERE id=?", (mission_id,))
        row = await cur.fetchone()
        cols = [c[0] for c in cur.description]
        m = dict(zip(cols, row))

    if p["energy"] < m["energy_cost"]:
        await interaction.response.send_message("😫 You’re too pooped to trot. (Not enough energy.)", ephemeral=True)
        return

    embed = discord.Embed(
        title=f"🚚 Mission: {m['name']}",
        description=(f"**Energy:** {m['energy_cost']} • **Time:** ~{m['time_sec']}s • **Chance:** {m['success_pct']}%\n\n"
                     f"Ready to hoof it, {interaction.user.mention}?"),
        color=discord.Color.dark_gold()
    )
    view = discord.ui.View(timeout=60)

    @discord.ui.button(label="Start Mission", style=discord.ButtonStyle.green, emoji="🏁")
    async def start_btn(btn_inter: discord.Interaction, _):
        if btn_inter.user.id != interaction.user.id:
            await btn_inter.response.send_message("❌ This ain’t your mud pit.", ephemeral=True)
            return
        await run_mission(btn_inter, m)

    view.add_item(start_btn)
    await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

async def run_mission(interaction: discord.Interaction, m: Dict[str, Any]):
    async with aiosqlite.connect(DB_PATH) as db:
        p = await get_player(db, interaction.user.id, interaction.guild_id, interaction.user.display_name)
        p["energy"] -= m["energy_cost"]
        await save_player(db, p)

    await interaction.response.defer(ephemeral=True, thinking=True)
    await asyncio.sleep(min(3, m["time_sec"]))

    success_roll = random.randint(1, 100)
    success = success_roll <= m["success_pct"]
    cash_gain = random.randint(m["cash_min"], m["cash_max"]) if success else 0
    xp_gain = random.randint(m["xp_min"], m["xp_max"]) if success else random.randint(1, 3)
    heat_gain = m["heat_add"] if success else 0

    async with aiosqlite.connect(DB_PATH) as db:
        p = await get_player(db, interaction.user.id, interaction.guild_id, interaction.user.display_name)
        p["cash"] += cash_gain
        p["xp"] += xp_gain
        p["heat"] += heat_gain
        while p["xp"] >= xp_to_next(p["level"]):
            p["xp"] -= xp_to_next(p["level"])
            p["level"] += 1
            p["attack"] += 1
            p["defense"] += 1
            p["strength"] += 1
            p["agility"] += 1
        await save_player(db, p)

    if success:
        title = f"✅ Squeal-cess! {m['name']}"
        desc = (f"You trotted true!\n**+${cash_gain} cash • +{xp_gain} XP • +{heat_gain} heat**")
        color = discord.Color.brand_green()
    else:
        title = f"❌ Oink… Failed: {m['name']}"
        desc = (f"You slipped in the slop.\n**+{xp_gain} XP** (consolation bacon)")
        color = discord.Color.red()

    embed = discord.Embed(title=title, description=desc, color=color)
    await interaction.followup.send(embed=embed, ephemeral=True)

# ---- Shop ----
class ShopCategory(discord.ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(label="Weapons", value="weapon", emoji="🗡️", description="Sharpen those tusks."),
            discord.SelectOption(label="Armor", value="armor", emoji="🛡️", description="Hide like a hide."),
            discord.SelectOption(label="Consumables", value="consumable", emoji="🧪", description="Snack n’ stack."),
        ]
        super().__init__(placeholder="Pick a shop category", options=options, min_values=1, max_values=1)

    async def callback(self, interaction: discord.Interaction):
        await show_shop_items(interaction, self.values[0])

class BuySelect(discord.ui.Select):
    def __init__(self, items: List[Dict[str, Any]]):
        options = [
            discord.SelectOption(
                label=f"{i['name']} (${i['cost']})",
                description=f"Lv{i['min_level']} • ATK {i['atk']} DEF {i['def']}",
                value=str(i["id"])
            ) for i in items
        ]
        super().__init__(placeholder="Choose pig-ware to purchase", options=options, min_values=1, max_values=1)

    async def callback(self, interaction: discord.Interaction):
        item_id = int(self.values[0])
        await handle_buy(interaction, item_id)

async def show_shop(interaction: discord.Interaction):
    embed = discord.Embed(
        title="🏪 Hog Street Market",
        description="Pick your poison from the pen:",
        color=discord.Color.blurple()
    )
    view = discord.ui.View(timeout=180)
    view.add_item(ShopCategory())
    await interaction.response.edit_message(embed=embed, view=view)

async def show_shop_items(interaction: discord.Interaction, category: str):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT * FROM items WHERE type=? ORDER BY min_level ASC", (category,))
        rows = await cur.fetchall()
        cols = [c[0] for c in cur.description]
        items = [dict(zip(cols, r)) for r in rows]

    embed = discord.Embed(
        title=f"🏪 {category.title()}",
        description="Select the goods you fancy from the trough.",
        color=discord.Color.blurple()
    )
    view = discord.ui.View(timeout=180)
    view.add_item(BuySelect(items))
    await interaction.response.edit_message(embed=embed, view=view)

async def handle_buy(interaction: discord.Interaction, item_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        p = await get_player(db, interaction.user.id, interaction.guild_id, interaction.user.display_name)
        cur = await db.execute("SELECT * FROM items WHERE id=?", (item_id,))
        row = await cur.fetchone()
        cols = [c[0] for c in cur.description]
        it = dict(zip(cols, row))

        if p["level"] < it["min_level"]:
            await interaction.response.send_message("Too wee a piglet for that gear.", ephemeral=True)
            return
        if p["cash"] < it["cost"]:
            await interaction.response.send_message("Your wallet squeals: ‘Empty!’", ephemeral=True)
            return

        p["cash"] -= it["cost"]
        p["attack"] += it["atk"]
        p["defense"] += it["def"]
        p["hp"] = min(100 + it["hp_bonus"], p["hp"] + it["hp_bonus"])
        await save_player(db, p)
        await db.execute("""INSERT INTO inventory(player_id,guild_id,item_id,qty,equipped)
                            VALUES(?,?,?,?,?)
                            ON CONFLICT(player_id,guild_id,item_id) DO UPDATE SET qty=qty+1""",
                         (interaction.user.id, interaction.guild_id, item_id, 1, 0))
        await db.commit()

    embed = discord.Embed(
        title="✅ Purchase Complete",
        description=f"You bought **{it['name']}** for **${it['cost']}**. Oink-come prepared.",
        color=discord.Color.brand_green()
    )
    await interaction.response.send_message(embed=embed, ephemeral=True)

# ---- Profile ----
async def show_profile(interaction: discord.Interaction):
    async with aiosqlite.connect(DB_PATH) as db:
        p = await get_player(db, interaction.user.id, interaction.guild_id, interaction.user.display_name)
        await regen_energy(db, p)
        need = xp_to_next(p["level"])

    bar = f"{p['xp']}/{need} XP"
    embed = discord.Embed(
        title=f"📊 {interaction.user.display_name}'s Hogfile",
        description=(
            f"**Level:** {p['level']}  •  **XP:** {bar}\n"
            f"**HP:** {p['hp']}  •  **Energy:** {p['energy']}\n"
            f"**ATK:** {p['attack']}  •  **DEF:** {p['defense']}\n"
            f"**STR:** {p['strength']}  •  **AGI:** {p['agility']}  •  **LCK:** {p['luck']}\n"
            f"**Cash:** ${p['cash']}  •  **Bank:** ${p['bank']}\n"
            f"**Respect:** {p['respect']}  •  **Heat:** {p['heat']}\n"
        ),
        color=discord.Color.greyple()
    )
    embed.set_footer(text="Stay boar-ed or get rewarded. Your call.")
    await interaction.response.edit_message(embed=embed, view=None)

# ---- Properties ----
class PropertySelect(discord.ui.Select):
    def __init__(self, props: List[Dict[str, Any]]):
        options = [
            discord.SelectOption(
                label=f"{p['name']} (Lv{p['min_level']})",
                description=f"Buy ${p['buy_cost']} • Income {p['base_income']}/h • Upkeep {p['upkeep']}/h",
                value=str(p["id"])
            ) for p in props
        ]
        super().__init__(placeholder="Pick a pig-folio property…", options=options, min_values=1, max_values=1)

    async def callback(self, interaction: discord.Interaction):
        await property_detail(interaction, int(self.values[0]))

async def show_properties(interaction: discord.Interaction):
    async with aiosqlite.connect(DB_PATH) as db:
        p = await get_player(db, interaction.user.id, interaction.guild_id, interaction.user.display_name)
        cur = await db.execute("SELECT * FROM properties ORDER BY min_level ASC")
        rows = await cur.fetchall()
        cols = [c[0] for c in cur.description]
        props = [dict(zip(cols, r)) for r in rows]

    embed = discord.Embed(
        title="🏠 Hog Holdings",
        description="Diversify your snout-folio. Buy, upgrade, and collect hourly oink-come.",
        color=discord.Color.green()
    )
    embed.set_footer(text=f"Cash: ${p['cash']}")
    view = discord.ui.View(timeout=180)
    view.add_item(PropertySelect(props))
    await interaction.response.edit_message(embed=embed, view=view)

async def property_detail(interaction: discord.Interaction, prop_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        p = await get_player(db, interaction.user.id, interaction.guild_id, interaction.user.display_name)
        cur = await db.execute("SELECT * FROM properties WHERE id=?", (prop_id,))
        row = await cur.fetchone()
        cols = [c[0] for c in cur.description]
        prop = dict(zip(cols, row))
        cur = await db.execute("""SELECT level,last_collected_at FROM player_properties
                                  WHERE player_id=? AND guild_id=? AND property_id=?""",
                               (interaction.user.id, interaction.guild_id, prop_id))
        owned = await cur.fetchone()

    owned_level = owned[0] if owned else 0
    last_col = owned[1] if owned else None
    hours = hours_since(last_col) if owned else 0.0
    ready_amt = property_income_for_hours(prop["base_income"], prop["upkeep"], max(owned_level,1), hours) if owned_level else 0

    desc = (
        f"**Buy:** ${prop['buy_cost']} • **Income/h:** {prop['base_income']} • **Upkeep/h:** {prop['upkeep']}\n"
        f"**Your Level:** {owned_level if owned_level else '—'} / {prop['upgrade_level_max']}  "
        f"{'(oink-come ready!)' if ready_amt>0 else ''}"
    )
    embed = discord.Embed(title=f"🏠 {prop['name']}", description=desc, color=discord.Color.green())
    if owned_level:
        embed.add_field(name="Pending Oink-come", value=f"${ready_amt}", inline=False)

    view = discord.ui.View(timeout=120)

    @discord.ui.button(label="Buy", style=discord.ButtonStyle.green, emoji="🛒", disabled=bool(owned_level))
    async def buy_btn(btn_inter: discord.Interaction, _):
        if btn_inter.user.id != interaction.user.id:
            return await btn_inter.response.send_message("🐽 Not your pig-vestment.", ephemeral=True)
        async with aiosqlite.connect(DB_PATH) as db:
            player = await get_player(db, btn_inter.user.id, btn_inter.guild_id, btn_inter.user.display_name)
            if player["level"] < prop["min_level"]:
                return await btn_inter.response.send_message("Too piglet to purchase this pen.", ephemeral=True)
            if player["cash"] < prop["buy_cost"]:
                return await btn_inter.response.send_message("Wallet squeals: insufficient bacon.", ephemeral=True)
            player["cash"] -= prop["buy_cost"]
            await save_player(db, player)
            await db.execute("""INSERT OR IGNORE INTO player_properties
                                (player_id,guild_id,property_id,level,last_collected_at)
                                VALUES(?,?,?,?,?)""",
                             (btn_inter.user.id, btn_inter.guild_id, prop_id, 1, now_iso()))
            await db.commit()
        await property_detail(btn_inter, prop_id)

    @discord.ui.button(label="Upgrade", style=discord.ButtonStyle.blurple, emoji="⬆️", disabled=not owned_level or owned_level>=prop["upgrade_level_max"])
    async def upg_btn(btn_inter: discord.Interaction, _):
        if btn_inter.user.id != interaction.user.id:
            return await btn_inter.response.send_message("Hooves off that upgrade!", ephemeral=True)
        upgrade_cost = int(prop["buy_cost"] * (0.6 + 0.4 * owned_level))
        async with aiosqlite.connect(DB_PATH) as db:
            player = await get_player(db, btn_inter.user.id, btn_inter.guild_id, btn_inter.user.display_name)
            if player["cash"] < upgrade_cost:
                return await btn_inter.response.send_message(f"Need ${upgrade_cost} to upgrade.", ephemeral=True)
            player["cash"] -= upgrade_cost
            await save_player(db, player)
            await db.execute("""UPDATE player_properties
                                SET level=level+1
                                WHERE player_id=? AND guild_id=? AND property_id=?""",
                             (btn_inter.user.id, btn_inter.guild_id, prop_id))
            await db.commit()
        await property_detail(btn_inter, prop_id)

    @discord.ui.button(label="Collect", style=discord.ButtonStyle.gray, emoji="💰", disabled=not owned_level or ready_amt<=0)
    async def collect_btn(btn_inter: discord.Interaction, _):
        if btn_inter.user.id != interaction.user.id:
            return await btn_inter.response.send_message("That’s not your trough.", ephemeral=True)
        async with aiosqlite.connect(DB_PATH) as db:
            cur = await db.execute("""SELECT level,last_collected_at FROM player_properties
                                      WHERE player_id=? AND guild_id=? AND property_id=?""",
                                   (btn_inter.user.id, btn_inter.guild_id, prop_id))
            row = await cur.fetchone()
            lvl = row[0]
            hrs = hours_since(row[1])
            amt = property_income_for_hours(prop["base_income"], prop["upkeep"], lvl, hrs)
            player = await get_player(db, btn_inter.user.id, btn_inter.guild_id, btn_inter.user.display_name)
            player["cash"] += amt
            await save_player(db, player)
            await db.execute("""UPDATE player_properties SET last_collected_at=? 
                                WHERE player_id=? AND guild_id=? AND property_id=?""",
                             (now_iso(), btn_inter.user.id, btn_inter.guild_id, prop_id))
            await db.commit()
        await btn_inter.response.send_message(embed=discord.Embed(
            title="💰 Oink-come Collected",
            description=f"You raked in **${amt}** from **{prop['name']}**. Sows well done.",
            color=discord.Color.gold()
        ), ephemeral=True)
        await property_detail(btn_inter, prop_id)

    view.add_item(buy_btn); view.add_item(upg_btn); view.add_item(collect_btn)
    await interaction.response.edit_message(embed=embed, view=view)

# ---- Businesses ----
class BusinessSelect(discord.ui.Select):
    def __init__(self, biz: List[Dict[str, Any]]):
        risk_map = {1:"Low",2:"Med",3:"High"}
        opts = [discord.SelectOption(
            label=f"{b['name']} (Lv{b['min_level']})",
            description=f"Buy ${b['buy_cost']} • {b['cycle_hours']}h cycles • {risk_map.get(b['risk'],'?')} risk",
            value=str(b["id"])
        ) for b in biz]
        super().__init__(placeholder="Pick a big-snout business…", options=opts, min_values=1, max_values=1)

    async def callback(self, interaction: discord.Interaction):
        await business_detail(interaction, int(self.values[0]))

async def show_businesses(interaction: discord.Interaction):
    async with aiosqlite.connect(DB_PATH) as db:
        p = await get_player(db, interaction.user.id, interaction.guild_id, interaction.user.display_name)
        cur = await db.execute("SELECT * FROM businesses ORDER BY min_level ASC")
        rows = await cur.fetchall()
        cols = [c[0] for c in cur.description]
        biz = [dict(zip(cols, r)) for r in rows]

    embed = discord.Embed(
        title="🏭 Hog Enterprises",
        description="Bigger chops, bigger crops. Cyclical payouts with a side of squeal-risk.",
        color=discord.Color.dark_teal()
    )
    embed.set_footer(text=f"Cash: ${p['cash']}")
    view = discord.ui.View(timeout=180)
    view.add_item(BusinessSelect(biz))
    await interaction.response.edit_message(embed=embed, view=view)

async def business_detail(interaction: discord.Interaction, biz_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        p = await get_player(db, interaction.user.id, interaction.guild_id, interaction.user.display_name)
        cur = await db.execute("SELECT * FROM businesses WHERE id=?", (biz_id,))
        row = await cur.fetchone()
        cols = [c[0] for c in cur.description]
        b = dict(zip(cols, row))
        cur = await db.execute("""SELECT level,last_cycle_at FROM player_businesses
                                  WHERE player_id=? AND guild_id=? AND business_id=?""",
                               (interaction.user.id, interaction.guild_id, biz_id))
        owned = await cur.fetchone()

    owned_level = owned[0] if owned else 0
    last_cycle = owned[1] if owned else None
    ready_cycles = cycles_elapsed(last_cycle, b["cycle_hours"]) if owned_level else 0

    desc = (
        f"**Buy:** ${b['buy_cost']} • **Cycle:** {b['cycle_hours']}h • "
        f"**Payout:** ${b['payout_min']}-{b['payout_max']} (minus upkeep ${b['upkeep_per_cycle']})\n"
        f"**Your Level:** {owned_level if owned_level else '—'}  •  **Ready cycles:** {ready_cycles}"
    )
    embed = discord.Embed(title=f"🏭 {b['name']}", description=desc, color=discord.Color.dark_teal())
    view = discord.ui.View(timeout=120)

    @discord.ui.button(label="Buy", style=discord.ButtonStyle.green, emoji="🛒", disabled=bool(owned_level))
    async def buy_btn(btn_inter: discord.Interaction, _):
        if btn_inter.user.id != interaction.user.id:
            return await btn_inter.response.send_message("Corporate hogwash — not your deal.", ephemeral=True)
        async with aiosqlite.connect(DB_PATH) as db:
            player = await get_player(db, btn_inter.user.id, btn_inter.guild_id, btn_inter.user.display_name)
            if player["level"] < b["min_level"]:
                return await btn_inter.response.send_message("You need more boar-droom experience.", ephemeral=True)
            if player["cash"] < b["buy_cost"]:
                return await btn_inter.response.send_message("Insufficient snout-capital.", ephemeral=True)
            player["cash"] -= b["buy_cost"]
            await save_player(db, player)
            await db.execute("""INSERT OR IGNORE INTO player_businesses
                                (player_id,guild_id,business_id,level,last_cycle_at)
                                VALUES(?,?,?,?,?)""",
                             (btn_inter.user.id, btn_inter.guild_id, biz_id, 1, now_iso()))
            await db.commit()
        await business_detail(btn_inter, biz_id)

    @discord.ui.button(label="Upgrade", style=discord.ButtonStyle.blurple, emoji="⬆️", disabled=not owned_level)
    async def upg_btn(btn_inter: discord.Interaction, _):
        if btn_inter.user.id != interaction.user.id:
            return await btn_inter.response.send_message("Hands off the ledgers, pig-pal.", ephemeral=True)
        up_cost = int(b["buy_cost"] * (0.75 + 0.5 * owned_level))
        async with aiosqlite.connect(DB_PATH) as db:
            player = await get_player(db, btn_inter.user.id, btn_inter.guild_id, btn_inter.user.display_name)
            if player["cash"] < up_cost:
                return await btn_inter.response.send_message(f"Need ${up_cost} to upgrade.", ephemeral=True)
            player["cash"] -= up_cost
            await save_player(db, player)
            await db.execute("""UPDATE player_businesses SET level=level+1
                                WHERE player_id=? AND guild_id=? AND business_id=?""",
                             (btn_inter.user.id, btn_inter.guild_id, biz_id))
            await db.commit()
        await business_detail(btn_inter, biz_id)

    @discord.ui.button(label="Collect", style=discord.ButtonStyle.gray, emoji="💼", disabled=not owned_level or ready_cycles<=0)
    async def collect_btn(btn_inter: discord.Interaction, _):
        if btn_inter.user.id != interaction.user.id:
            return await btn_inter.response.send_message("That payout ain’t yours, pork-partner.", ephemeral=True)
        async with aiosqlite.connect(DB_PATH) as db:
            cur = await db.execute("""SELECT level,last_cycle_at FROM player_businesses
                                      WHERE player_id=? AND guild_id=? AND business_id=?""",
                                   (btn_inter.user.id, btn_inter.guild_id, biz_id))
            row = await cur.fetchone()
            lvl = row[0]
            ready = cycles_elapsed(row[1], b["cycle_hours"])
            total = 0
            for _ in range(ready):
                gross = random.randint(b["payout_min"], b["payout_max"])
                gross = int(round(gross * (1.0 + 0.20 * (lvl - 1))))  # +20% per level
                net = max(0, gross - (b["upkeep_per_cycle"] * lvl))
                shave_pct = random.randint(0, b["risk"] * 5)  # small random risk
                net = int(round(net * (1 - shave_pct / 100)))
                total += net
            player = await get_player(db, btn_inter.user.id, btn_inter.guild_id, btn_inter.user.display_name)
            player["cash"] += total
            await save_player(db, player)
            await db.execute("""UPDATE player_businesses SET last_cycle_at=? 
                                WHERE player_id=? AND guild_id=? AND business_id=?""",
                             (now_iso(), btn_inter.user.id, btn_inter.guild_id, biz_id))
            await db.commit()
        await btn_inter.response.send_message(embed=discord.Embed(
            title="💼 Quarterly Oink-nings",
            description=f"You pocketed **${total}** from **{b['name']}**. Snout-standing returns!",
            color=discord.Color.gold()
        ), ephemeral=True)
        await business_detail(btn_inter, biz_id)

    view.add_item(buy_btn); view.add_item(upg_btn); view.add_item(collect_btn)
    await interaction.response.edit_message(embed=embed, view=view)

# ---- PvP ----
FIGHT_CD_SECONDS = 45

class TargetSelect(discord.ui.Select):
    def __init__(self, options: List[discord.SelectOption]):
        super().__init__(placeholder="Pick a hog to head-butt…", options=options, min_values=1, max_values=1)

    async def callback(self, interaction: discord.Interaction):
        target_id = int(self.values[0])
        await fight_prompt(interaction, target_id)

async def show_fight(interaction: discord.Interaction):
    members = [m for m in interaction.guild.members if (not m.bot and m.id != interaction.user.id)]
    members = sorted(members, key=lambda m: m.display_name.lower())[:25]
    if not members:
        return await interaction.response.edit_message(
            embed=discord.Embed(title="⚔️ Fight", description="No eligible pork-ticipants found.", color=discord.Color.red()),
            view=None
        )
    options = [discord.SelectOption(label=m.display_name, value=str(m.id)) for m in members]
    embed = discord.Embed(title="⚔️ Find a Foepig", description="Choose your squeal-nemesis from the dropdown.", color=discord.Color.red())
    view = discord.ui.View(timeout=180); view.add_item(TargetSelect(options))
    await interaction.response.edit_message(embed=embed, view=view)

async def fight_prompt(interaction: discord.Interaction, target_id: int):
    target = interaction.guild.get_member(target_id)
    if not target:
        return await interaction.response.send_message("That hog left the pen.", ephemeral=True)
    async with aiosqlite.connect(DB_PATH) as db:
        atk = await get_player(db, interaction.user.id, interaction.guild_id, interaction.user.display_name)
        dfn = await get_player(db, target.id, interaction.guild_id, target.display_name)
        cd = await get_cd(db, interaction.user.id, interaction.guild_id, "pvp")
        if cd > 0:
            return await interaction.response.send_message(f"⏳ Your trotters are cooling. Try again in {int(cd)}s.", ephemeral=True)
        if atk["level"] < 3:
            return await interaction.response.send_message("Piglet, reach level 3 before brawling.", ephemeral=True)

    desc = (f"**Attacker:** {interaction.user.mention} (Lv{atk['level']})\n"
            f"**Defender:** {target.mention} (Lv{dfn['level']})\n\n"
            f"Ready to crack tusks?")
    embed = discord.Embed(title="⚔️ Challenge", description=desc, color=discord.Color.red())
    view = discord.ui.View(timeout=60)

    @discord.ui.button(label="Attack!", style=discord.ButtonStyle.red, emoji="🐽")
    async def attack_btn(btn_inter: discord.Interaction, _):
        if btn_inter.user.id != interaction.user.id:
            return await btn_inter.response.send_message("Not your grudge-match, buddy.", ephemeral=True)
        await resolve_fight(btn_inter, target)

    view.add_item(attack_btn)
    await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

def _roll_damage(p: Dict[str, Any]) -> int:
    return p["attack"] + random.randint(0, max(1, p["strength"]))

def _roll_block(p: Dict[str, Any]) -> int:
    return p["defense"] + random.randint(0, max(1, p["agility"]))

async def resolve_fight(interaction: discord.Interaction, defender_member: discord.Member):
    async with aiosqlite.connect(DB_PATH) as db:
        a = await get_player(db, interaction.user.id, interaction.guild_id, interaction.user.display_name)
        d = await get_player(db, defender_member.id, interaction.guild_id, defender_member.display_name)
        await set_cd(db, a["player_id"], a["guild_id"], "pvp", FIGHT_CD_SECONDS)

        # two-way exchange; break ties once
        for _ in range(2):
            atk_roll = _roll_damage(a); def_block = _roll_block(d); d_net = max(1, atk_roll - def_block)
            def_roll = _roll_damage(d); atk_block = _roll_block(a); a_net = max(1, def_roll - atk_block)
            if d_net != a_net:
                break

        if d_net > a_net:
            cash_steal_pct = random.randint(5, 15)
            steal = min(d["cash"], int(d["cash"] * cash_steal_pct / 100))
            d["cash"] -= steal; a["cash"] += steal; a["respect"] += 1; a["heat"] += 1
            result_txt = f"{interaction.user.mention} **wins** and snorts **${steal}** from {defender_member.mention}!"
            color = discord.Color.brand_green()
        elif a_net > d_net:
            cash_steal_pct = random.randint(3, 10)
            steal = min(a["cash"], int(a["cash"] * cash_steal_pct / 100))
            a["cash"] -= steal; d["cash"] += steal; d["respect"] += 1; a["heat"] += 1
            result_txt = f"{defender_member.mention} **counters** and snouts **${steal}** from {interaction.user.mention}!"
            color = discord.Color.red()
        else:
            steal = 0
            a["heat"] += 1
            result_txt = "It’s a muddy **draw**. Both hogs slip in the slop."
            color = discord.Color.orange()

        await save_player(db, a); await save_player(db, d)
        await db.execute("""INSERT INTO fights(attacker_id,defender_id,guild_id,result,cash_delta,created_at)
                            VALUES(?,?,?,?,?,?)""",
                         (a["player_id"], d["player_id"], a["guild_id"], result_txt, steal, dt.datetime.utcnow().isoformat()))
        await db.commit()

    embed = discord.Embed(
        title="⚔️ Hogfight Results",
        description=(f"**Your swing:** {d_net} vs **Their swing:** {a_net}\n\n" + result_txt),
        color=color
    )
    await interaction.response.edit_message(embed=embed, view=None)

# ---- Utility Commands ----
@bot.tree.command(name="menu", description="Open your HOGSTERS HQ menu.")
async def menu_cmd(interaction: discord.Interaction):
    async with aiosqlite.connect(DB_PATH) as db:
        await get_player(db, interaction.user.id, interaction.guild_id, interaction.user.display_name)
    embed = discord.Embed(
        title="🐗 HOGSTERS HQ",
        description=("Welcome to the syndi-snout. Choose a section below.\n"
                     "Pro tip: Keep your trotters clean and your tusks cleaner."),
        color=discord.Color.dark_gold()
    )
    view = MainMenu(interaction.user)
    await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

@bot.tree.command(name="fights", description="Show your last few tussles.")
async def fights_cmd(interaction: discord.Interaction):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("""SELECT result, created_at FROM fights
                                  WHERE guild_id=? AND (attacker_id=? OR defender_id=?)
                                  ORDER BY id DESC LIMIT 5""",
                               (interaction.guild_id, interaction.user.id, interaction.user.id))
        rows = await cur.fetchall()
    if not rows:
        return await interaction.response.send_message("No hoof-to-hoof history yet.", ephemeral=True)
    lines = [f"• {r[0]}  *(at {r[1]})*" for r in rows]
    await interaction.response.send_message(
        embed=discord.Embed(title="🥊 Recent Hogfights", description="\n".join(lines), color=discord.Color.dark_gray()),
        ephemeral=True
    )

# ----------------- Entrypoint -----------------
if __name__ == "__main__":
    if not TOKEN:
        raise SystemExit("Missing DISCORD_TOKEN in .env")
    bot.run(TOKEN)
